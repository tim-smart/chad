/**
 * Provides the service used to run outgoing HTTP requests.
 *
 * `HttpClient` executes immutable `HttpClientRequest` values and returns
 * `HttpClientResponse` values. Keeping HTTP behind this service lets programs,
 * tests, and generated API clients use the same request model without depending
 * on one concrete platform transport. This module includes request accessors,
 * constructors and layers, request and response transformations, status
 * filtering, retries, rate limiting, cookies, redirect handling, scoped request
 * abortion, and tracing support.
 *
 * @stability unstable
 * @since 4.0.0
 */
import type { NonEmptyReadonlyArray } from "../Array.ts"
import * as Cause from "../Cause.ts"
import { Clock } from "../Clock.ts"
import * as Context from "../Context.ts"
import * as Duration from "../Duration.ts"
import * as Effect from "../Effect.ts"
import * as Exit from "../Exit.ts"
import * as Fiber from "../Fiber.ts"
import { constant, constFalse, constTrue, dual, flow, identity } from "../Function.ts"
import * as Inspectable from "../Inspectable.ts"
import { getStackTraceLimit, setStackTraceLimit } from "../internal/stackTraceLimit.ts"
import * as Layer from "../Layer.ts"
import * as Option from "../Option.ts"
import type * as CircuitBreaker from "../persistence/CircuitBreaker.ts"
import type * as RateLimiter from "../persistence/RateLimiter.ts"
import { type Pipeable, pipeArguments } from "../Pipeable.ts"
import * as Predicate from "../Predicate.ts"
import * as Ref from "../Ref.ts"
import * as References from "../References.ts"
import * as Result from "../Result.ts"
import * as Schedule from "../Schedule.ts"
import * as Scope from "../Scope.ts"
import * as Stream from "../Stream.ts"
import * as Tracer from "../Tracer.ts"
import type { EqualsWith, ExcludeTag, ExtractTag, NoExcessProperties, NoInfer, Tags } from "../Types.ts"
import * as Cookies from "./Cookies.ts"
import * as Headers from "./Headers.ts"
import * as HttpBody from "./HttpBody.ts"
import * as Error from "./HttpClientError.ts"
import * as HttpClientRequest from "./HttpClientRequest.ts"
import * as HttpClientResponse from "./HttpClientResponse.ts"
import * as HttpIncomingMessage from "./HttpIncomingMessage.ts"
import * as HttpMethod from "./HttpMethod.ts"
import * as TraceContext from "./HttpTraceContext.ts"
import * as tracing from "./internal/tracing.ts"
import { getWebSource, WebSourceSymbol } from "./internal/webResponse.ts"
import * as Url from "./Url.ts"
import * as UrlParams from "./UrlParams.ts"

const TypeId = "~effect/http/HttpClient"

/**
 * Returns `true` if the provided value is an `HttpClient`.
 *
 * @stability unstable
 * @category guards
 * @since 4.0.0
 */
export const isHttpClient = (u: unknown): u is HttpClient => Predicate.hasProperty(u, TypeId)

/**
 * HTTP client whose requests produce `HttpClientResponse` values and can fail with `HttpClientError`.
 *
 * @stability unstable
 * @category models
 * @since 4.0.0
 */
export interface HttpClient extends HttpClient.With<Error.HttpClientError> {}

/**
 * Namespace containing type-level members associated with `HttpClient`.
 *
 * @stability unstable
 * @since 4.0.0
 */
export declare namespace HttpClient {
  /**
   * Parameterized HTTP client that may fail with `E` and require environment `R`.
   *
   * **Details**
   *
   * It exposes preprocessing, postprocessing, direct request execution, and method-specific helpers.
   *
   * @stability unstable
   * @category models
   * @since 4.0.0
   */
  export interface With<E, R = never> extends Pipeable, Inspectable.Inspectable {
    readonly [TypeId]: typeof TypeId
    readonly preprocess: Preprocess<E, R>
    readonly postprocess: Postprocess<E, R>
    readonly execute: (
      request: HttpClientRequest.HttpClientRequest
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>

    readonly get: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly query: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly head: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly post: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly patch: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly put: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly del: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    readonly options: (
      url: string | URL,
      options?: HttpClientRequest.Options.NoUrl
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
  }

  /**
   * Effectful transformation applied to a request before the client executes it.
   *
   * @stability unstable
   * @category models
   * @since 4.0.0
   */
  export type Preprocess<E, R> = (
    request: HttpClientRequest.HttpClientRequest
  ) => Effect.Effect<HttpClientRequest.HttpClientRequest, E, R>

  /**
   * Function that turns a preprocessed request effect into the response effect executed by the client.
   *
   * @stability unstable
   * @category models
   * @since 4.0.0
   */
  export type Postprocess<E = never, R = never> = (
    request: Effect.Effect<HttpClientRequest.HttpClientRequest, E, R>
  ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
}

/**
 * Service tag for the default outgoing HTTP client service.
 *
 * **When to use**
 *
 * Use to provide the default outgoing HTTP client service used by request
 * accessors such as `execute`, `get`, and `post`.
 *
 * @stability unstable
 * @category services
 * @since 4.0.0
 */
export const HttpClient: Context.Service<HttpClient, HttpClient> = Context.Service<HttpClient, HttpClient>(
  "effect/HttpClient"
)

const accessor = (method: keyof HttpClient) => (...args: Array<any>): Effect.Effect<any, any, any> =>
  Effect.flatMap(
    HttpClient,
    (client) => (client as any)[method](...args)
  )

/**
 * Executes a prebuilt `HttpClientRequest` using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const execute: (
  request: HttpClientRequest.HttpClientRequest
) => Effect.Effect<HttpClientResponse.HttpClientResponse, Error.HttpClientError, HttpClient> = accessor("execute")

/**
 * Executes a `GET` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const get: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("get")

/**
 * Executes a `QUERY` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const query: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("query")

/**
 * Executes a `HEAD` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const head: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("head")

/**
 * Executes a `POST` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const post: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("post")

/**
 * Executes a `PATCH` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const patch: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("patch")

/**
 * Executes a `PUT` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const put: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("put")

/**
 * Executes a `DELETE` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const del: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("del")

/**
 * Executes an `OPTIONS` request using the `HttpClient` service from the environment.
 *
 * @stability unstable
 * @category accessors
 * @since 4.0.0
 */
export const options: (url: string | URL, options?: HttpClientRequest.Options.NoUrl | undefined) => Effect.Effect<
  HttpClientResponse.HttpClientResponse,
  Error.HttpClientError,
  HttpClient
> = accessor("options")

/**
 * Transforms a client by wrapping the response effect for each request.
 *
 * **Details**
 *
 * The transformation receives both the response effect and the original request, allowing it to change success, error, and environment behavior.
 *
 * @stability unstable
 * @category mapping
 * @since 4.0.0
 */
export const transform: {
  /**
   * Transforms a client by wrapping the response effect for each request.
   *
   * **Details**
   *
   * The transformation receives both the response effect and the original request, allowing it to change success, error, and environment behavior.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R, E1, R1>(
    f: (
      effect: Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>,
      request: HttpClientRequest.HttpClientRequest
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): (self: HttpClient.With<E, R>) => HttpClient.With<E | E1, R | R1>
  /**
   * Transforms a client by wrapping the response effect for each request.
   *
   * **Details**
   *
   * The transformation receives both the response effect and the original request, allowing it to change success, error, and environment behavior.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R, E1, R1>(
    self: HttpClient.With<E, R>,
    f: (
      effect: Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>,
      request: HttpClientRequest.HttpClientRequest
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): HttpClient.With<E | E1, R | R1>
} = dual(2, <E, R, E1, R1>(
  self: HttpClient.With<E, R>,
  f: (
    effect: Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>,
    request: HttpClientRequest.HttpClientRequest
  ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
): HttpClient.With<E | E1, R | R1> =>
  makeWith(
    Effect.flatMap((request) => f(self.postprocess(Effect.succeed(request)), request)),
    self.preprocess
  ))

/**
 * Transforms a client by applying an effectful transformation to each response effect.
 *
 * @stability unstable
 * @category mapping
 * @since 4.0.0
 */
export const transformResponse: {
  /**
   * Transforms a client by applying an effectful transformation to each response effect.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R, E1, R1>(
    f: (
      effect: Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): (self: HttpClient.With<E, R>) => HttpClient.With<E1, R1>
  /**
   * Transforms a client by applying an effectful transformation to each response effect.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R, E1, R1>(
    self: HttpClient.With<E, R>,
    f: (
      effect: Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): HttpClient.With<E1, R1>
} = dual(2, <E, R, E1, R1>(
  self: HttpClient.With<E, R>,
  f: (
    effect: Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>
  ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
): HttpClient.With<E1, R1> => makeWith((request) => f(self.postprocess(request)), self.preprocess))

const catch_: {
  <E, E2, R2>(
    f: (e: E) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): <R>(self: HttpClient.With<E, R>) => HttpClient.With<E2, R2 | R>
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (e: E) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): HttpClient.With<E2, R | R2>
} = dual(
  2,
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (e: E) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): HttpClient.With<E2, R | R2> => transformResponse(self, Effect.catch(f))
)

/**
 * @stability unstable
 */
export {
  /**
   * Handles all client failures with an effectful recovery function and returns a transformed client.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  catch_ as catch
}

/**
 * Handles client failures with one or more matching `_tag` values and returns a transformed client.
 *
 * @stability unstable
 * @category error handling
 * @since 4.0.0
 */
export const catchTag: {
  /**
   * Handles client failures with one or more matching `_tag` values and returns a transformed client.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <K extends Tags<E> | NonEmptyReadonlyArray<Tags<E>>, E, E1, R1>(
    tag: K,
    f: (
      e: ExtractTag<NoInfer<E>, K extends NonEmptyReadonlyArray<string> ? K[number] : K>
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): <R>(
    self: HttpClient.With<E, R>
  ) => HttpClient.With<E1 | ExcludeTag<E, K extends NonEmptyReadonlyArray<string> ? K[number] : K>, R1 | R>
  /**
   * Handles client failures with one or more matching `_tag` values and returns a transformed client.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <R, E, K extends Tags<E> | NonEmptyReadonlyArray<Tags<E>>, R1, E1>(
    self: HttpClient.With<E, R>,
    tag: K,
    f: (
      e: ExtractTag<E, K extends NonEmptyReadonlyArray<string> ? K[number] : K>
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): HttpClient.With<E1 | ExcludeTag<E, K extends NonEmptyReadonlyArray<string> ? K[number] : K>, R1 | R>
} = dual(
  3,
  <R, E, K extends Tags<E> | NonEmptyReadonlyArray<Tags<E>>, R1, E1>(
    self: HttpClient.With<E, R>,
    tag: K,
    f: (
      e: ExtractTag<E, K extends NonEmptyReadonlyArray<string> ? K[number] : K>
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E1, R1>
  ): HttpClient.With<E1 | ExcludeTag<E, K extends NonEmptyReadonlyArray<string> ? K[number] : K>, R1 | R> =>
    transformResponse(
      self,
      // TypeScript 7.1 does not relate the error type `Effect.catchTag` returns
      // to the `ExcludeTag` declared here, because each declares its own copy
      // of the conditional on `K`. The assertion restates the declared type.
      (effect) =>
        Effect.catchTag<HttpClientResponse.HttpClientResponse, E, R, K, R1, E1, HttpClientResponse.HttpClientResponse>(
          effect,
          tag,
          f
        ) as Effect.Effect<
          HttpClientResponse.HttpClientResponse,
          E1 | ExcludeTag<E, K extends NonEmptyReadonlyArray<string> ? K[number] : K>,
          R | R1
        >
    )
)

/**
 * Handles client failures by matching their `_tag` values against a case map.
 *
 * @stability unstable
 * @category error handling
 * @since 4.0.0
 */
export const catchTags: {
  /**
   * Handles client failures by matching their `_tag` values against a case map.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <
    E,
    Cases extends
      & {
        [K in Extract<E, { _tag: string }>["_tag"]]+?: (
          error: Extract<E, { _tag: K }>
        ) => Effect.Effect<HttpClientResponse.HttpClientResponse, any, any>
      }
      & (unknown extends E ? {} : { [K in Exclude<keyof Cases, Extract<E, { _tag: string }>["_tag"]>]: never })
  >(cases: Cases): <R>(
    self: HttpClient.With<E, R>
  ) => HttpClient.With<
    | Exclude<E, { _tag: keyof Cases }>
    | {
      [K in keyof Cases]: Cases[K] extends (...args: Array<any>) => Effect.Effect<any, infer E, any> ? E : never
    }[keyof Cases],
    | R
    | {
      [K in keyof Cases]: Cases[K] extends (...args: Array<any>) => Effect.Effect<any, any, infer R> ? R : never
    }[keyof Cases]
  >
  /**
   * Handles client failures by matching their `_tag` values against a case map.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <
    E extends { _tag: string },
    R,
    Cases extends
      & {
        [K in Extract<E, { _tag: string }>["_tag"]]+?: (
          error: Extract<E, { _tag: K }>
        ) => Effect.Effect<HttpClientResponse.HttpClientResponse, any, any>
      }
      & (unknown extends E ? {} : { [K in Exclude<keyof Cases, Extract<E, { _tag: string }>["_tag"]>]: never })
  >(self: HttpClient.With<E, R>, cases: Cases): HttpClient.With<
    | Exclude<E, { _tag: keyof Cases }>
    | {
      [K in keyof Cases]: Cases[K] extends (...args: Array<any>) => Effect.Effect<any, infer E, any> ? E : never
    }[keyof Cases],
    | R
    | {
      [K in keyof Cases]: Cases[K] extends (...args: Array<any>) => Effect.Effect<any, any, infer R> ? R : never
    }[keyof Cases]
  >
} = dual(
  2,
  <
    E extends { _tag: string },
    R,
    Cases extends
      & {
        [K in Extract<E, { _tag: string }>["_tag"]]+?: (
          error: Extract<E, { _tag: K }>
        ) => Effect.Effect<HttpClientResponse.HttpClientResponse, any, any>
      }
      & (unknown extends E ? {}
        : {
          [
            K in Exclude<
              keyof Cases,
              Extract<E, { _tag: string }>["_tag"]
            >
          ]: never
        })
  >(
    self: HttpClient.With<E, R>,
    cases: Cases
  ): HttpClient.With<
    | Exclude<E, { _tag: keyof Cases }>
    | {
      [K in keyof Cases]: Cases[K] extends (
        ...args: Array<any>
      ) => Effect.Effect<any, infer E, any> ? E
        : never
    }[keyof Cases],
    | R
    | {
      [K in keyof Cases]: Cases[K] extends (
        ...args: Array<any>
      ) => Effect.Effect<any, any, infer R> ? R
        : never
    }[keyof Cases]
  > => transformResponse(self, Effect.catchTags(cases) as any)
)

/**
 * Filters the result of a response, or runs an alternative effect if the predicate fails.
 *
 * @stability unstable
 * @category filtering
 * @since 4.0.0
 */
export const filterOrElse: {
  /**
   * Filters the result of a response, or runs an alternative effect if the predicate fails.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <B extends HttpClientResponse.HttpClientResponse, E2, R2>(
    refinement: Predicate.Refinement<NoInfer<HttpClientResponse.HttpClientResponse>, B>,
    orElse: (
      response: EqualsWith<
        HttpClientResponse.HttpClientResponse,
        B,
        NoInfer<HttpClientResponse.HttpClientResponse>,
        Exclude<NoInfer<HttpClientResponse.HttpClientResponse>, B>
      >
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E2 | E, R2 | R>
  /**
   * Filters the result of a response, or runs an alternative effect if the predicate fails.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E2, R2>(
    predicate: Predicate.Predicate<NoInfer<HttpClientResponse.HttpClientResponse>>,
    orElse: (
      response: NoInfer<HttpClientResponse.HttpClientResponse>
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E2 | E, R2 | R>
  /**
   * Filters the result of a response, or runs an alternative effect if the predicate fails.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E, R, B extends HttpClientResponse.HttpClientResponse, E2, R2>(
    self: HttpClient.With<E, R>,
    refinement: Predicate.Refinement<HttpClientResponse.HttpClientResponse, B>,
    orElse: (
      response: EqualsWith<
        HttpClientResponse.HttpClientResponse,
        B,
        HttpClientResponse.HttpClientResponse,
        Exclude<HttpClientResponse.HttpClientResponse, B>
      >
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): HttpClient.With<E2 | E, R2 | R>
  /**
   * Filters the result of a response, or runs an alternative effect if the predicate fails.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    predicate: Predicate.Predicate<HttpClientResponse.HttpClientResponse>,
    orElse: (
      response: HttpClientResponse.HttpClientResponse
    ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E2, R2>
  ): HttpClient.With<E2 | E, R2 | R>
} = dual(3, (self, f, orElse) => transformResponse(self, Effect.filterOrElse(f, orElse)))

/**
 * Filters successful responses, or fails with the error produced by `orFailWith` when the predicate does not match.
 *
 * @stability unstable
 * @category filtering
 * @since 4.0.0
 */
export const filterOrFail: {
  /**
   * Filters successful responses, or fails with the error produced by `orFailWith` when the predicate does not match.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <B extends HttpClientResponse.HttpClientResponse, E2>(
    refinement: Predicate.Refinement<NoInfer<HttpClientResponse.HttpClientResponse>, B>,
    orFailWith: (response: NoInfer<HttpClientResponse.HttpClientResponse>) => E2
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E2 | E, R>
  /**
   * Filters successful responses, or fails with the error produced by `orFailWith` when the predicate does not match.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E2>(
    predicate: Predicate.Predicate<NoInfer<HttpClientResponse.HttpClientResponse>>,
    orFailWith: (response: NoInfer<HttpClientResponse.HttpClientResponse>) => E2
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E2 | E, R>
  /**
   * Filters successful responses, or fails with the error produced by `orFailWith` when the predicate does not match.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E, R, B extends HttpClientResponse.HttpClientResponse, E2>(
    self: HttpClient.With<E, R>,
    refinement: Predicate.Refinement<NoInfer<HttpClientResponse.HttpClientResponse>, B>,
    orFailWith: (response: NoInfer<HttpClientResponse.HttpClientResponse>) => E2
  ): HttpClient.With<E2 | E, R>
  /**
   * Filters successful responses, or fails with the error produced by `orFailWith` when the predicate does not match.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E, R, E2>(
    self: HttpClient.With<E, R>,
    predicate: Predicate.Predicate<NoInfer<HttpClientResponse.HttpClientResponse>>,
    orFailWith: (response: NoInfer<HttpClientResponse.HttpClientResponse>) => E2
  ): HttpClient.With<E2 | E, R>
} = dual(3, (self, f, orFailWith) => transformResponse(self, Effect.filterOrFail(f, orFailWith)))

/**
 * Filters responses by HTTP status code.
 *
 * @stability unstable
 * @category filtering
 * @since 4.0.0
 */
export const filterStatus: {
  /**
   * Filters responses by HTTP status code.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  (f: (status: number) => boolean): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | Error.HttpClientError, R>
  /**
   * Filters responses by HTTP status code.
   *
   * @stability unstable
   * @category filtering
   * @since 4.0.0
   */
  <E, R>(self: HttpClient.With<E, R>, f: (status: number) => boolean): HttpClient.With<E | Error.HttpClientError, R>
} = dual(
  2,
  <E, R>(self: HttpClient.With<E, R>, f: (status: number) => boolean): HttpClient.With<E | Error.HttpClientError, R> =>
    transformResponse(self, Effect.flatMap(HttpClientResponse.filterStatus(f)))
)

/**
 * Filters responses that return a 2xx status code.
 *
 * @stability unstable
 * @category filtering
 * @since 4.0.0
 */
export const filterStatusOk: <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | Error.HttpClientError, R> =
  transformResponse(Effect.flatMap(HttpClientResponse.filterStatusOk))

/**
 * Constructs an `HttpClient.With` from a preprocessing function and a postprocessing function.
 *
 * **Details**
 *
 * `execute` applies preprocessing to the request and then passes the resulting request effect to postprocessing.
 *
 * @stability unstable
 * @category constructors
 * @since 4.0.0
 */
export const makeWith = <E2, R2, E, R>(
  postprocess: (
    request: Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ) => Effect.Effect<HttpClientResponse.HttpClientResponse, E, R>,
  preprocess: HttpClient.Preprocess<E2, R2>
): HttpClient.With<E, R> => {
  const self = Object.create(Proto)
  self.preprocess = preprocess
  self.postprocess = postprocess
  self.execute = function(request: HttpClientRequest.HttpClientRequest) {
    return postprocess(preprocess(request))
  }
  return self
}

const Proto = {
  [TypeId]: TypeId,
  pipe() {
    return pipeArguments(this, arguments)
  },
  ...Inspectable.BaseProto,
  toJSON() {
    return {
      _id: "effect/HttpClient"
    }
  },
  ...Object.fromEntries(
    HttpMethod.allShort.map((
      [fullMethod, method]
    ) => [method, function(this: HttpClient, url: string | URL, options?: HttpClientRequest.Options.NoUrl) {
      return this.execute(HttpClientRequest.make(fullMethod)(url, options))
    }])
  )
}

/**
 * Constructs an `HttpClient` from a low-level request runner.
 *
 * **Details**
 *
 * The runner receives the request, resolved URL, abort signal, and current fiber. The client wrapper handles URL construction failures, tracing and propagation, header redaction, aborting the signal when the request is interrupted before a response arrives, and attaching each request to the scope of an enclosing `withScope`.
 *
 * `HttpClientError` reasons redact their URL with the `UrlParams.CurrentRedactedNames` of the fiber that executed the request, even when a callback outside that fiber creates them. The client adds those names to the errors the runner fails with and to errors built later from the response. Rendering an error then adds the names of the rendering fiber. A runner that returns one response object to several executions gives its errors the names of all of them.
 *
 * @stability unstable
 * @category constructors
 * @since 4.0.0
 */
export const make = (
  f: (
    request: HttpClientRequest.HttpClientRequest,
    url: URL,
    signal: AbortSignal,
    fiber: Fiber.Fiber<HttpClientResponse.HttpClientResponse, Error.HttpClientError>
  ) => Effect.Effect<HttpClientResponse.HttpClientResponse, Error.HttpClientError>
): HttpClient =>
  makeWith((effect) =>
    Effect.flatMap(effect, (request) =>
      Effect.withFiber((fiber) => {
        const scope = fiber.getRef(RequestScope)
        const controller = new AbortController()
        const urlParamsRedactedNames = fiber.getRef(UrlParams.CurrentRedactedNames)
        const urlResult = Url.make(request.url, request.urlParams, Option.getOrUndefined(request.hash))
        if (Result.isFailure(urlResult)) {
          return Effect.fail(
            new Error.HttpClientError({
              reason: new Error.InvalidUrlError({
                request,
                cause: urlResult.failure
              })
            })
          )
        }
        const url = urlResult.success
        const send = (request: HttpClientRequest.HttpClientRequest) =>
          scope === undefined
            ? f(request, url, controller.signal, fiber as any)
            // Register the abort before dispatch, so a scope that is already
            // closed aborts the signal before the transport sees it
            : Effect.flatMap(
              Scope.addFinalizer(scope, Effect.sync(() => controller.abort())),
              () => f(request, url, controller.signal, fiber as any)
            )
        const exchange = (
          request: HttpClientRequest.HttpClientRequest,
          onResponse?: (response: HttpClientResponse.HttpClientResponse) => void
        ) =>
          Effect.uninterruptibleMask((restore) =>
            Effect.matchCauseEffect(restore(send(request)), {
              onSuccess: (response) => {
                response = trackResponse(response, controller, scope !== undefined, urlParamsRedactedNames)
                onResponse?.(response)
                return Effect.succeed(response)
              },
              onFailure: (cause) => {
                if (Cause.hasInterrupts(cause)) {
                  controller.abort()
                }
                Error.addFailureRedactedNames(cause, urlParamsRedactedNames)
                return Effect.failCause(cause)
              }
            })
          )
        const tracerDisabled = !fiber.getRef(References.TracerEnabled) ||
          fiber.getRef(Tracer.DisablePropagation) ||
          fiber.getRef(TracerDisabledWhen)(request)
        if (tracerDisabled) {
          return exchange(request)
        }
        return Effect.useSpan(
          fiber.getRef(SpanNameGenerator)(request),
          { kind: "client" },
          (span) => {
            span.attribute("http.request.method", request.method)
            const redactedHeaderNames = fiber.getRef(Headers.CurrentRedactedNames)
            tracing.addUrlAttributes(
              span,
              url,
              tracing.redactedNames(request.urlParams, urlParamsRedactedNames)
            )
            const headerFilter = fiber.getRef(TracerHeaderFilter)
            tracing.addHeaderAttributes(span, "request", request.headers, headerFilter, redactedHeaderNames)
            request = fiber.getRef(TracerPropagationEnabled)
              ? HttpClientRequest.setHeaders(request, TraceContext.toHeaders(span))
              : request
            return Effect.withParentSpan(
              exchange(request, (response) => {
                span.attribute("http.response.status_code", response.status)
                tracing.addHeaderAttributes(span, "response", response.headers, headerFilter, redactedHeaderNames)
                // OpenTelemetry marks client spans as failed for 4xx and
                // 5xx responses, while the response itself still succeeds.
                if (response.status >= 400 && response.status < 600) {
                  span.attribute("error.type", String(response.status))
                  endSpanWithStatusError(fiber, span, request, response)
                }
              }),
              span,
              { captureStackTrace: false }
            )
          }
        )
      })), Effect.succeed as HttpClient.Preprocess<never, never>)

const endSpanWithStatusError = (
  fiber: Fiber.Fiber<unknown, unknown>,
  span: Tracer.Span,
  request: HttpClientRequest.HttpClientRequest,
  response: HttpClientResponse.HttpClientResponse
): void => {
  const stackTraceLimit = getStackTraceLimit()
  setStackTraceLimit(0)
  let exit: Exit.Exit<never, Error.HttpClientError>
  try {
    exit = Exit.fail(new Error.HttpClientError({ reason: new Error.StatusCodeError({ request, response }) }))
  } finally {
    setStackTraceLimit(stackTraceLimit)
  }
  span.end(
    fiber.getRef(References.TracerTimingEnabled) ? fiber.getRef(Clock).currentTimeNanosUnsafe() : BigInt(0),
    exit
  )
}

/**
 * Appends a transformation of the request object before sending it.
 *
 * @stability unstable
 * @category mapping
 * @since 4.0.0
 */
export const mapRequest: {
  /**
   * Appends a transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  (
    f: (a: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E, R>
  /**
   * Appends a transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest
  ): HttpClient.With<E, R>
} = dual(
  2,
  <E, R>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest
  ): HttpClient.With<E, R> => makeWith(self.postprocess, (request) => Effect.map(self.preprocess(request), f))
)

/**
 * Appends an effectful transformation of the request object before sending it.
 *
 * @stability unstable
 * @category mapping
 * @since 4.0.0
 */
export const mapRequestEffect: {
  /**
   * Appends an effectful transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E2, R2>(
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | E2, R | R2>
  /**
   * Appends an effectful transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ): HttpClient.With<E | E2, R | R2>
} = dual(
  2,
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ): HttpClient.With<E | E2, R | R2> =>
    makeWith(self.postprocess as any, (request) => Effect.flatMap(self.preprocess(request), f))
)

/**
 * Prepends a transformation of the request object before sending it.
 *
 * @stability unstable
 * @category mapping
 * @since 4.0.0
 */
export const mapRequestInput: {
  /**
   * Prepends a transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  (
    f: (a: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E, R>
  /**
   * Prepends a transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest
  ): HttpClient.With<E, R>
} = dual(
  2,
  <E, R>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => HttpClientRequest.HttpClientRequest
  ): HttpClient.With<E, R> => makeWith(self.postprocess, (request) => self.preprocess(f(request)))
)

/**
 * Prepends an effectful transformation of the request object before sending it.
 *
 * @stability unstable
 * @category mapping
 * @since 4.0.0
 */
export const mapRequestInputEffect: {
  /**
   * Prepends an effectful transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E2, R2>(
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | E2, R | R2>
  /**
   * Prepends an effectful transformation of the request object before sending it.
   *
   * @stability unstable
   * @category mapping
   * @since 4.0.0
   */
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ): HttpClient.With<E | E2, R | R2>
} = dual(
  2,
  <E, R, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientRequest.HttpClientRequest, E2, R2>
  ): HttpClient.With<E | E2, R | R2> =>
    makeWith(self.postprocess as any, (request) => Effect.flatMap(f(request), self.preprocess))
)

/**
 * Namespace containing type-level helpers for retrying HTTP clients.
 *
 * @stability unstable
 * @since 4.0.0
 */
export declare namespace Retry {
  /**
   * Computes the client type returned by `retry` for a given set of retry options.
   *
   * **Details**
   *
   * The result includes errors and requirements introduced by schedules and effectful retry predicates.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  export type Return<R, E, O extends NoExcessProperties<Effect.Retry.Options<E>, O>> = HttpClient.With<
    | (O extends { schedule: Schedule.Schedule<infer _O, infer _I, infer _E, infer _R> } ? E | _E
      : O extends { times: number } ? E
      : O extends { until: Predicate.Refinement<E, infer E2> } ? E2
      : E)
    | (O extends { while: (...args: Array<any>) => Effect.Effect<infer _A, infer E, infer _R> } ? E : never)
    | (O extends { until: (...args: Array<any>) => Effect.Effect<infer _A, infer E, infer _R> } ? E : never),
    | R
    | (O extends { schedule: Schedule.Schedule<infer _O, infer _I, infer _E, infer R> } ? R : never)
    | (O extends { while: (...args: Array<any>) => Effect.Effect<infer _A, infer _E, infer R> } ? R : never)
    | (O extends { until: (...args: Array<any>) => Effect.Effect<infer _A, infer _E, infer R> } ? R : never)
  > extends infer Z ? Z : never
}

/**
 * Retries the request based on a provided schedule or policy.
 *
 * @stability unstable
 * @category error handling
 * @since 4.0.0
 */
export const retry: {
  /**
   * Retries the request based on a provided schedule or policy.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <E, O extends NoExcessProperties<Effect.Retry.Options<E>, O>>(options: O): <R>(self: HttpClient.With<E, R>) => Retry.Return<R, E, O>
  /**
   * Retries the request based on a provided schedule or policy.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <B, E, ES, R1>(policy: Schedule.Schedule<B, NoInfer<E>, ES, R1>): <R>(self: HttpClient.With<E, R>) => HttpClient.With<E | ES, R1 | R>
  /**
   * Retries the request based on a provided schedule or policy.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <E, R, O extends NoExcessProperties<Effect.Retry.Options<E>, O>>(self: HttpClient.With<E, R>, options: O): Retry.Return<R, E, O>
  /**
   * Retries the request based on a provided schedule or policy.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <E, R, B, ES, R1>(self: HttpClient.With<E, R>, policy: Schedule.Schedule<B, E, ES, R1>): HttpClient.With<E | ES, R1 | R>
} = dual(
  2,
  <E extends E0, E0, ES, R, R1, B>(
    self: HttpClient.With<E, R>,
    policy: Schedule.Schedule<B, E0, ES, R1>
  ): HttpClient.With<E | ES, R | R1> => transformResponse(self, Effect.retry(policy))
)

/**
 * Retries common transient errors, such as rate limiting, timeouts or network issues.
 *
 * **When to use**
 *
 * Use to focus on retrying errors, transient responses, or both.
 *
 * **Details**
 *
 * Specifying a `while` predicate allows you to consider other errors as
 * transient, and is ignored in "response-only" mode.
 *
 * A `Retry-After` header on a transient response, or on the response of a
 * status code error, sets the minimum delay before the next attempt.
 *
 * @stability unstable
 * @category error handling
 * @since 4.0.0
 */
export const retryTransient: {
  /**
   * Retries common transient errors, such as rate limiting, timeouts or network issues.
   *
   * **When to use**
   *
   * Use to focus on retrying errors, transient responses, or both.
   *
   * **Details**
   *
   * Specifying a `while` predicate allows you to consider other errors as
   * transient, and is ignored in "response-only" mode.
   *
   * A `Retry-After` header on a transient response, or on the response of a
   * status code error, sets the minimum delay before the next attempt.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <
    E,
    B = never,
    ES = never,
    R1 = never,
    const RetryOn extends "errors-only" | "response-only" | "errors-and-responses" =
      | "errors-only"
      | "response-only"
      | "errors-and-responses",
    Input = RetryOn extends "errors-only" ? E
      : RetryOn extends "response-only" ? HttpClientResponse.HttpClientResponse
      : HttpClientResponse.HttpClientResponse | E
  >(
    options: {
      readonly retryOn?: RetryOn | undefined
      readonly while?: Predicate.Predicate<NoInfer<E | ES>>
      readonly schedule?: Schedule.Schedule<B, NoInfer<Input>, ES, R1>
      readonly times?: number
    }
  ): <R>(self: HttpClient.With<E, R>) => HttpClient.With<E | ES, R1 | R>
  /**
   * Retries common transient errors, such as rate limiting, timeouts or network issues.
   *
   * **When to use**
   *
   * Use to focus on retrying errors, transient responses, or both.
   *
   * **Details**
   *
   * Specifying a `while` predicate allows you to consider other errors as
   * transient, and is ignored in "response-only" mode.
   *
   * A `Retry-After` header on a transient response, or on the response of a
   * status code error, sets the minimum delay before the next attempt.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <
    E,
    R,
    B = never,
    ES = never,
    R1 = never,
    const RetryOn extends "errors-only" | "response-only" | "errors-and-responses" =
      | "errors-only"
      | "response-only"
      | "errors-and-responses",
    Input = RetryOn extends "errors-only" ? E
      : RetryOn extends "response-only" ? HttpClientResponse.HttpClientResponse
      : HttpClientResponse.HttpClientResponse | E
  >(
    self: HttpClient.With<E, R>,
    options: {
      readonly retryOn?: RetryOn | undefined
      readonly while?: Predicate.Predicate<NoInfer<E | ES>>
      readonly schedule?: Schedule.Schedule<B, NoInfer<Input>, ES, R1>
      readonly times?: number
    }
  ): HttpClient.With<E | ES, R1 | R>
  /**
   * Retries common transient errors, such as rate limiting, timeouts or network issues.
   *
   * **When to use**
   *
   * Use to focus on retrying errors, transient responses, or both.
   *
   * **Details**
   *
   * Specifying a `while` predicate allows you to consider other errors as
   * transient, and is ignored in "response-only" mode.
   *
   * A `Retry-After` header on a transient response, or on the response of a
   * status code error, sets the minimum delay before the next attempt.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <B, E, ES = never, R1 = never>(
    options: Schedule.Schedule<B, NoInfer<HttpClientResponse.HttpClientResponse | E>, ES, R1>
  ): <R>(self: HttpClient.With<E, R>) => HttpClient.With<E | ES, R1 | R>
  /**
   * Retries common transient errors, such as rate limiting, timeouts or network issues.
   *
   * **When to use**
   *
   * Use to focus on retrying errors, transient responses, or both.
   *
   * **Details**
   *
   * Specifying a `while` predicate allows you to consider other errors as
   * transient, and is ignored in "response-only" mode.
   *
   * A `Retry-After` header on a transient response, or on the response of a
   * status code error, sets the minimum delay before the next attempt.
   *
   * @stability unstable
   * @category error handling
   * @since 4.0.0
   */
  <E, R, B, ES = never, R1 = never>(
    self: HttpClient.With<E, R>,
    options: Schedule.Schedule<B, NoInfer<HttpClientResponse.HttpClientResponse | E>, ES, R1>
  ): HttpClient.With<E | ES, R1 | R>
} = dual(
  2,
  <
    E,
    R,
    B,
    ES = never,
    R1 = never
  >(
    self: HttpClient.With<E, R>,
    options: {
      readonly retryOn?: "errors-only" | "response-only" | "errors-and-responses" | undefined
      readonly while?: Predicate.Predicate<E | ES>
      readonly schedule?: Schedule.Schedule<B, any, ES, R1>
      readonly times?: number
    } | Schedule.Schedule<B, any, ES, R1>
  ): HttpClient.With<E | ES, R1 | R> => {
    const isOnlySchedule = Schedule.isSchedule(options)
    const retryOn = isOnlySchedule ? "errors-and-responses" : options.retryOn ?? "errors-and-responses"
    const schedule = withRetryAfter(
      isOnlySchedule ? options : options.schedule ?? Schedule.forever
    )
    const times = isOnlySchedule ? undefined : options.times
    return transformResponse(
      self,
      flow(
        retryOn === "errors-only" ? identity : Effect.repeat({
          schedule,
          times,
          while: isTransientResponse
        }),
        retryOn === "response-only" ? identity : Effect.retry({
          while: isOnlySchedule || options.while === undefined
            ? isTransientError
            : Predicate.or(isTransientError, options.while),
          schedule,
          times
        })
      )
    )
  }
)

/**
 * Fails requests that do not receive a response within the given duration.
 *
 * **When to use**
 *
 * Use to configure a timeout once on the client, for example when providing
 * the `HttpClient` service, while keeping the standard `HttpClientError` error
 * model.
 *
 * **Details**
 *
 * A timed out request is interrupted and fails with an `HttpClientError` whose
 * reason is a `TransportError` with a `Cause.TimeoutError` cause.
 * `retryTransient` treats it as transient. Interrupting a request while it
 * waits for response headers aborts the underlying transport.
 *
 * The timer starts after request preprocessing and covers everything the
 * wrapped client does to produce a response. For a plain client this ends when
 * the response headers arrive, but response middleware applied before
 * `timeout`, such as `tap` or `retryTransient`, runs inside the budget,
 * including any body reads it performs. Composition order therefore decides
 * how it interacts with retries: applying `timeout` before `retryTransient`
 * gives each attempt its own budget, while applying it after bounds the whole
 * retry loop.
 *
 * **Gotchas**
 *
 * Body reads outside the timed client are not covered, including those made
 * by response middleware applied after `timeout` and by consumers of the
 * `HttpClient` service. Apply a separate timeout to body reads such as
 * `response.json` or `response.stream` when needed.
 *
 * For a client wrapped with `withScope`, a timeout that fires after the
 * response headers arrive, such as during a body read by response middleware,
 * does not abort the transport. The connection stays open until the scope
 * closes.
 *
 * **Example** (Timing out each attempt)
 *
 * ```ts
 * import { Effect, Layer } from "effect"
 * import { FetchHttpClient, HttpClient } from "effect/http"
 *
 * const TimedHttpClient = Layer.effect(
 *   HttpClient.HttpClient,
 *   Effect.map(
 *     HttpClient.HttpClient,
 *     HttpClient.timeout("5 seconds")
 *   )
 * ).pipe(Layer.provide(FetchHttpClient.layer))
 *
 * const program = Effect.gen(function*() {
 *   const client = (yield* HttpClient.HttpClient).pipe(
 *     HttpClient.retryTransient({ times: 3 })
 *   )
 *   return yield* client.get("https://example.com")
 * }).pipe(Effect.provide(TimedHttpClient))
 * ```
 *
 * @stability unstable
 * @category error handling
 * @since 4.1.0
 */
export const timeout: {
  /**
   * Fails requests that do not receive a response within the given duration.
   *
   * **When to use**
   *
   * Use to configure a timeout once on the client, for example when providing
   * the `HttpClient` service, while keeping the standard `HttpClientError` error
   * model.
   *
   * **Details**
   *
   * A timed out request is interrupted and fails with an `HttpClientError` whose
   * reason is a `TransportError` with a `Cause.TimeoutError` cause.
   * `retryTransient` treats it as transient. Interrupting a request while it
   * waits for response headers aborts the underlying transport.
   *
   * The timer starts after request preprocessing and covers everything the
   * wrapped client does to produce a response. For a plain client this ends when
   * the response headers arrive, but response middleware applied before
   * `timeout`, such as `tap` or `retryTransient`, runs inside the budget,
   * including any body reads it performs. Composition order therefore decides
   * how it interacts with retries: applying `timeout` before `retryTransient`
   * gives each attempt its own budget, while applying it after bounds the whole
   * retry loop.
   *
   * **Gotchas**
   *
   * Body reads outside the timed client are not covered, including those made
   * by response middleware applied after `timeout` and by consumers of the
   * `HttpClient` service. Apply a separate timeout to body reads such as
   * `response.json` or `response.stream` when needed.
   *
   * For a client wrapped with `withScope`, a timeout that fires after the
   * response headers arrive, such as during a body read by response middleware,
   * does not abort the transport. The connection stays open until the scope
   * closes.
   *
   * **Example** (Timing out each attempt)
   *
   * ```ts
   * import { Effect, Layer } from "effect"
   * import { FetchHttpClient, HttpClient } from "effect/http"
   *
   * const TimedHttpClient = Layer.effect(
   *   HttpClient.HttpClient,
   *   Effect.map(
   *     HttpClient.HttpClient,
   *     HttpClient.timeout("5 seconds")
   *   )
   * ).pipe(Layer.provide(FetchHttpClient.layer))
   *
   * const program = Effect.gen(function*() {
   *   const client = (yield* HttpClient.HttpClient).pipe(
   *     HttpClient.retryTransient({ times: 3 })
   *   )
   *   return yield* client.get("https://example.com")
   * }).pipe(Effect.provide(TimedHttpClient))
   * ```
   *
   * @stability unstable
   * @category error handling
   * @since 4.1.0
   */
  (duration: Duration.Input): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | Error.HttpClientError, R>
  /**
   * Fails requests that do not receive a response within the given duration.
   *
   * **When to use**
   *
   * Use to configure a timeout once on the client, for example when providing
   * the `HttpClient` service, while keeping the standard `HttpClientError` error
   * model.
   *
   * **Details**
   *
   * A timed out request is interrupted and fails with an `HttpClientError` whose
   * reason is a `TransportError` with a `Cause.TimeoutError` cause.
   * `retryTransient` treats it as transient. Interrupting a request while it
   * waits for response headers aborts the underlying transport.
   *
   * The timer starts after request preprocessing and covers everything the
   * wrapped client does to produce a response. For a plain client this ends when
   * the response headers arrive, but response middleware applied before
   * `timeout`, such as `tap` or `retryTransient`, runs inside the budget,
   * including any body reads it performs. Composition order therefore decides
   * how it interacts with retries: applying `timeout` before `retryTransient`
   * gives each attempt its own budget, while applying it after bounds the whole
   * retry loop.
   *
   * **Gotchas**
   *
   * Body reads outside the timed client are not covered, including those made
   * by response middleware applied after `timeout` and by consumers of the
   * `HttpClient` service. Apply a separate timeout to body reads such as
   * `response.json` or `response.stream` when needed.
   *
   * For a client wrapped with `withScope`, a timeout that fires after the
   * response headers arrive, such as during a body read by response middleware,
   * does not abort the transport. The connection stays open until the scope
   * closes.
   *
   * **Example** (Timing out each attempt)
   *
   * ```ts
   * import { Effect, Layer } from "effect"
   * import { FetchHttpClient, HttpClient } from "effect/http"
   *
   * const TimedHttpClient = Layer.effect(
   *   HttpClient.HttpClient,
   *   Effect.map(
   *     HttpClient.HttpClient,
   *     HttpClient.timeout("5 seconds")
   *   )
   * ).pipe(Layer.provide(FetchHttpClient.layer))
   *
   * const program = Effect.gen(function*() {
   *   const client = (yield* HttpClient.HttpClient).pipe(
   *     HttpClient.retryTransient({ times: 3 })
   *   )
   *   return yield* client.get("https://example.com")
   * }).pipe(Effect.provide(TimedHttpClient))
   * ```
   *
   * @stability unstable
   * @category error handling
   * @since 4.1.0
   */
  <E, R>(self: HttpClient.With<E, R>, duration: Duration.Input): HttpClient.With<E | Error.HttpClientError, R>
} = dual(
  2,
  <E, R>(self: HttpClient.With<E, R>, duration: Duration.Input): HttpClient.With<E | Error.HttpClientError, R> => {
    const decoded = Duration.fromInputUnsafe(duration)
    const description = `timed out after ${Duration.format(decoded)}`
    return transform(self, (effect, request) =>
      Effect.timeoutOrElse(effect, {
        duration: decoded,
        orElse: () =>
          Effect.fail(
            new Error.HttpClientError({
              reason: new Error.TransportError({
                request,
                cause: new Cause.TimeoutError(`Operation ${description}`),
                description
              })
            })
          )
      }))
  }
)

/**
 * Namespace containing configuration types for `withRateLimiter`.
 *
 * @stability unstable
 * @since 4.0.0
 */
export declare namespace WithRateLimiter {
  /**
   * Options used to configure `withRateLimiter`.
   *
   * **Details**
   *
   * They define the backing limiter, initial limit window, keying strategy,
   * algorithm, token cost, retry count, and response header inspection.
   *
   * @stability unstable
   * @category rate limiting
   * @since 4.0.0
   */
  export interface Options {
    /**
     * The `RateLimiter` service to use for rate limiting.
     */
    readonly limiter: RateLimiter.RateLimiter
    /**
     * The initial rate limit window duration.
     */
    readonly window: Duration.Input
    /**
     * The initial maximum number of allowed requests in the window.
     */
    readonly limit: number
    /**
     * The key to identify the rate limit. Requests with the same key will share
     * the same rate limit. This can be used to implement per-user or
     * per-endpoint rate limits.
     */
    readonly key: string | ((request: HttpClientRequest.HttpClientRequest) => string)
    /**
     * Defaults to `"fixed-window"`.
     */
    readonly algorithm?: "fixed-window" | "token-bucket" | undefined
    /**
     * Defaults to `1`.
     */
    readonly tokens?: number | ((request: HttpClientRequest.HttpClientRequest) => number) | undefined
    /**
     * The maximum number of automatic retries after an HTTP `429` response.
     * Use a non-negative integer. Defaults to an unlimited number of retries.
     * Set to `0` to disable automatic retries.
     */
    readonly times?: number | undefined
    /**
     * Overrides the response header names used for rate limit inspection.
     * Header names are matched case-insensitively. An omitted field continues
     * using the built-in names, while a configured field replaces them for
     * that value. Header value formats are unchanged.
     */
    readonly responseHeaders?: {
      /**
       * Header containing the maximum number of requests in a window.
       */
      readonly limit?: string | undefined
      /**
       * Header containing the number of requests remaining in a window.
       */
      readonly remaining?: string | undefined
      /**
       * Header containing the rate limit reset time.
       */
      readonly reset?: string | undefined
      /**
       * Header containing the number of seconds until the rate limit resets.
       */
      readonly resetAfter?: string | undefined
      /**
       * Header containing the retry delay for an HTTP `429` response.
       */
      readonly retryAfter?: string | undefined
    } | undefined
    /**
     * Disables automatic limit updates, `Retry-After` delays, and adaptive
     * feedback from response headers. This does not disable automatic HTTP
     * `429` retries. Set `times` to `0` to disable them.
     */
    readonly disableResponseInspection?: boolean | undefined
    /**
     * Disables adaptive learning from `Retry-After` responses. Response
     * inspection and direct `Retry-After` delays remain enabled.
     */
    readonly disableAdaptiveLearning?: boolean | undefined
  }
}

/**
 * Applies request rate limiting using the `RateLimiter` service.
 *
 * **Details**
 *
 * It can update limits by inspecting common rate limit response headers and
 * automatically retries HTTP `429` responses (or `HttpClientError` values
 * wrapping a `429` response) by forcing the retry back through the limiter.
 * When a response reports the remaining budget, requests wait for the
 * reported reset once that budget is exhausted.
 *
 * **Gotchas**
 *
 * Automatic HTTP `429` retries are unlimited unless `times` is specified.
 * Disabling response inspection does not disable retries; set `times` to `0`
 * to return or fail with the first `429`.
 *
 * @stability unstable
 * @category rate limiting
 * @since 4.0.0
 */
export const withRateLimiter: {
  /**
   * Applies request rate limiting using the `RateLimiter` service.
   *
   * **Details**
   *
   * It can update limits by inspecting common rate limit response headers and
   * automatically retries HTTP `429` responses (or `HttpClientError` values
   * wrapping a `429` response) by forcing the retry back through the limiter.
   * When a response reports the remaining budget, requests wait for the
   * reported reset once that budget is exhausted.
   *
   * **Gotchas**
   *
   * Automatic HTTP `429` retries are unlimited unless `times` is specified.
   * Disabling response inspection does not disable retries; set `times` to `0`
   * to return or fail with the first `429`.
   *
   * @stability unstable
   * @category rate limiting
   * @since 4.0.0
   */
  (options: WithRateLimiter.Options): <E, R>(
    self: HttpClient.With<E, R>
  ) => HttpClient.With<E | RateLimiter.RateLimiterError, R>
  /**
   * Applies request rate limiting using the `RateLimiter` service.
   *
   * **Details**
   *
   * It can update limits by inspecting common rate limit response headers and
   * automatically retries HTTP `429` responses (or `HttpClientError` values
   * wrapping a `429` response) by forcing the retry back through the limiter.
   * When a response reports the remaining budget, requests wait for the
   * reported reset once that budget is exhausted.
   *
   * **Gotchas**
   *
   * Automatic HTTP `429` retries are unlimited unless `times` is specified.
   * Disabling response inspection does not disable retries; set `times` to `0`
   * to return or fail with the first `429`.
   *
   * @stability unstable
   * @category rate limiting
   * @since 4.0.0
   */
  <E, R>(self: HttpClient.With<E, R>, options: WithRateLimiter.Options): HttpClient.With<E | RateLimiter.RateLimiterError, R>
} = dual(2, <E, R>(
  self: HttpClient.With<E, R>,
  options: WithRateLimiter.Options
): HttpClient.With<E | RateLimiter.RateLimiterError, R> => {
  const initialState: RateLimiterState = {
    initial: true,
    limit: options.limit,
    window: Duration.max(Duration.fromInputUnsafe(options.window), Duration.millis(1))
  }
  const states = new Map<string, RateLimiterState>()

  const keyOption = options.key
  const resolveKey: (request: HttpClientRequest.HttpClientRequest) => string = typeof keyOption === "function"
    ? keyOption
    : constant(keyOption)
  const tokensOption = options.tokens
  const resolveTokens: (request: HttpClientRequest.HttpClientRequest) => number = typeof tokensOption === "function"
    ? tokensOption
    : constant(tokensOption ?? 1)
  const adaptiveLearningEnabled = !options.disableAdaptiveLearning
  const headerNames = resolveRateLimiterHeaderNames(options.responseHeaders)

  const getState = (key: string): RateLimiterState => {
    const current = states.get(key)
    if (current !== undefined) {
      return current
    }
    states.set(key, initialState)
    return initialState
  }

  const budgets = new Map<string, RateLimitBudget>()
  const getBudget = (key: string): RateLimitBudget => {
    let budget = budgets.get(key)
    if (budget === undefined) {
      budget = { sent: 0, observed: 0, remaining: 0, resetAt: 0 }
      budgets.set(key, budget)
    }
    return budget
  }

  const onResponse = options.disableResponseInspection
    ? undefined
    : (clock: Clock, key: string, headers: Headers.Headers, tokens: number, sent: number) => {
      const current = getState(key)
      const next = parseRateLimiterState(current, clock, headers, tokens, headerNames)
      if (next.limit !== current.limit || !Duration.equals(next.window, current.window)) {
        states.set(key, next)
      }
      const remaining = parseRateLimitRemaining(headers, headerNames)
      const budget = getBudget(key)
      // responses to earlier requests carry stale counts
      if (remaining === undefined || sent <= budget.observed) {
        return
      }
      const resetAfter = parseRateLimitWindow(clock, headers, headerNames)
      budget.observed = sent
      budget.remaining = remaining
      if (resetAfter !== undefined) {
        budget.resetAt = clock.currentTimeMillisUnsafe() + Duration.toMillis(resetAfter)
      }
    }

  return transform(self, function loop(effect, request, retries = 0): Effect.Effect<
    HttpClientResponse.HttpClientResponse,
    E | RateLimiter.RateLimiterError,
    R
  > {
    const fiber = Fiber.getCurrent()!
    const clock = fiber.getRef(Clock)
    const key = resolveKey(request)
    const tokens = Math.max(resolveTokens(request), 1)
    const budget = getBudget(key)
    const now = clock.currentTimeMillisUnsafe()
    // requests admitted after the observed one are not reflected in its count
    if (budget.resetAt > now && budget.remaining - (budget.sent - budget.observed) < tokens) {
      return Effect.flatMap(Effect.sleep(budget.resetAt - now), () => loop(effect, request, retries))
    }
    // counted at admission, so requests already admitted are sent even if a
    // later response exhausts the budget
    const sent = budget.sent += tokens
    const current = getState(key)
    const canRetry = options.times === undefined || retries < options.times
    function retry(retryAfter: Duration.Duration | undefined) {
      return retryAfter
        ? Effect.flatMap(Effect.sleep(retryAfter), () => loop(effect, request, retries + 1))
        : loop(effect, request, retries + 1)
    }
    const inspectResponse = (
      response: HttpClientResponse.HttpClientResponse,
      adaptive: RateLimiter.AdaptiveConsumeResult | undefined
    ) => {
      onResponse?.(clock, key, response.headers, tokens, sent)
      if (options.disableResponseInspection || response.status !== 429) {
        return Effect.succeed<Duration.Duration | undefined>(undefined)
      }
      const retryAfter = parseRetryAfter(
        clock.currentTimeMillisUnsafe(),
        getHeader(response.headers, ...headerNames.retryAfter)
      )
      if (retryAfter === undefined) {
        return Effect.succeed<Duration.Duration | undefined>(undefined)
      }
      const delay = parseRateLimitWindow(clock, response.headers, headerNames) ?? retryAfter
      if (adaptive === undefined) {
        return Effect.succeed<Duration.Duration | undefined>(delay)
      }
      return Effect.as(
        options.limiter.adaptiveFeedback({
          key,
          epoch: adaptive.epoch,
          tokens,
          status: response.status,
          retryAfter: delay
        }),
        delay
      )
    }
    return Effect.flatMap(
      options.limiter.consume({
        algorithm: options.algorithm,
        onExceeded: "delay",
        key,
        limit: current.limit,
        window: current.window,
        tokens
      }),
      ({ delay }) => {
        const runAdaptive = (): Effect.Effect<
          HttpClientResponse.HttpClientResponse,
          E | RateLimiter.RateLimiterError,
          R
        > => {
          const runRequest = (adaptive: RateLimiter.AdaptiveConsumeResult | undefined) => {
            const request = Effect.matchEffect(effect, {
              onSuccess(response) {
                return Effect.flatMap(inspectResponse(response, adaptive), (retryAfter) => {
                  if (response.status !== 429 || !canRetry) return Effect.succeed(response)
                  return retry(retryAfter)
                })
              },
              onFailure(error) {
                if (isTooManyRequestsHttpClientError(error)) {
                  return Effect.flatMap(
                    inspectResponse(error.reason.response, adaptive),
                    (retryAfter) => canRetry ? retry(retryAfter) : Effect.fail(error)
                  )
                }
                return Effect.fail(error)
              }
            })
            return adaptive === undefined || Duration.isZero(adaptive.delay)
              ? request
              : Effect.delay(request, adaptive.delay)
          }
          if (!adaptiveLearningEnabled) {
            return runRequest(undefined)
          }
          return Effect.flatMap(
            options.limiter.adaptiveConsume({
              key,
              tokens,
              fallbackLimit: current.limit,
              fallbackWindow: current.window
            }),
            (adaptive) => {
              if (!Duration.isZero(adaptive.delay) && adaptive.phase === "cooldown") {
                return Effect.flatMap(Effect.sleep(adaptive.delay), runAdaptive)
              }
              return runRequest(adaptive)
            }
          )
        }
        return Duration.isZero(delay) ? runAdaptive() : Effect.flatMap(Effect.sleep(delay), runAdaptive)
      }
    )
  })
})

/**
 * Namespace containing configuration types for `withCircuitBreaker`.
 *
 * @stability experimental
 * @since 4.0.7
 */
export declare namespace WithCircuitBreaker {
  /**
   * Options used to configure `withCircuitBreaker`.
   *
   * @stability experimental
   * @category circuit breaking
   * @since 4.0.7
   */
  export interface Options<E, R2 = never> {
    /**
     * The `CircuitBreaker` service that guards each request.
     */
    readonly breaker: CircuitBreaker.CircuitBreaker
    /**
     * The circuit key for a request. Requests with the same key share one
     * circuit. Defaults to the request origin, falling back to the raw request
     * URL when it cannot be parsed.
     */
    readonly key?: string | ((request: HttpClientRequest.HttpClientRequest) => string) | undefined
    /**
     * Classifies the `Exit` of each request that the breaker admitted.
     * `context.probe` is `true` when the request is the HalfOpen probe.
     * Defaults to `circuitBreakerClassifier`.
     */
    readonly classify?: CircuitBreaker.Classifier<HttpClientResponse.HttpClientResponse, E, R2> | undefined
  }
}

/**
 * Guards requests with a `CircuitBreaker`.
 *
 * **Details**
 *
 * Requests are keyed by origin unless `key` is set, and classified with
 * `circuitBreakerClassifier` unless `classify` is set. A rejected request
 * fails with `CircuitBreakerError` without reaching the wrapped client.
 *
 * Apply it after `withRateLimiter` and `retryTransient`, so the breaker sees
 * one outcome per call and an open circuit skips the retry loop.
 * `retryTransient` never retries a `CircuitBreakerError`. A custom `classify`
 * can delegate the cases it doesn't handle to `circuitBreakerClassifier`.
 *
 * **Gotchas**
 *
 * - The breaker only sees the response headers. To count an error in the
 *   body, lift it into the error channel below the breaker with
 *   `transformResponse` and count it in `classify`.
 * - `withRateLimiter` retries `429` without limit by default, which can hold
 *   the probe slot for minutes. Set its `times`.
 * - A rejected request has no client span. The rejection fails the caller's
 *   span instead.
 *
 * **Example** (Guarding an API in the recommended order)
 *
 * ```ts import.meta.vitest
 * import { Effect, Layer, Ref, Schedule } from "effect"
 * import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http"
 * import { CircuitBreaker, RateLimiter } from "effect/persistence"
 *
 * const program = Effect.gen(function*() {
 *   const requests = yield* Ref.make(0)
 *   // A dependency that always answers 503.
 *   const unavailable = HttpClient.make((request) =>
 *     Effect.as(Ref.update(requests, (n) => n + 1), HttpClientResponse.fromWeb(request, new Response(null, { status: 503 })))
 *   )
 *
 *   const breaker = yield* CircuitBreaker.make({
 *     tripPolicy: CircuitBreaker.consecutive(1),
 *     openDuration: "30 seconds"
 *   })
 *   const client = unavailable.pipe(
 *     HttpClient.withRateLimiter({
 *       limiter: yield* RateLimiter.RateLimiter,
 *       key: "inventory",
 *       limit: 100,
 *       window: "1 second",
 *       times: 3
 *     }),
 *     HttpClient.retryTransient({ times: 2, schedule: Schedule.exponential("1 millis") }),
 *     HttpClient.withCircuitBreaker({ breaker })
 *   )
 *
 *   // Three attempts, then the breaker records one failure and opens.
 *   yield* client.execute(HttpClientRequest.get("http://inventory.test/items"))
 *   // Rejected before the retry loop starts, so no further request is sent.
 *   const rejected = yield* Effect.flip(client.execute(HttpClientRequest.get("http://inventory.test/items")))
 *
 *   return [yield* Ref.get(requests), rejected._tag]
 * }).pipe(
 *   Effect.scoped,
 *   Effect.provide(Layer.merge(
 *     CircuitBreaker.layerStoreMemory(),
 *     RateLimiter.layer.pipe(Layer.provide(RateLimiter.layerStoreMemory))
 *   ))
 * )
 *
 * await Effect.runPromise(program) // => [3, "CircuitBreakerError"]
 * ```
 *
 * **Example** (Counting an error in the body as a failure)
 *
 * This API answers `200` with `{ "status": "degraded" }` when it is failing.
 *
 * ```ts import.meta.vitest
 * import { Data, Effect, Exit, Option } from "effect"
 * import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http"
 * import { CircuitBreaker } from "effect/persistence"
 *
 * class Degraded extends Data.TaggedError("Degraded") {}
 *
 * const degraded = HttpClient.make((request) =>
 *   Effect.succeed(HttpClientResponse.fromWeb(request, Response.json({ status: "degraded" })))
 * )
 *
 * const program = Effect.gen(function*() {
 *   const breaker = yield* CircuitBreaker.make({
 *     tripPolicy: CircuitBreaker.consecutive(1),
 *     openDuration: "30 seconds"
 *   })
 *   const client = degraded.pipe(
 *     HttpClient.transformResponse(Effect.flatMap((response) =>
 *       Effect.flatMap(response.json, (body) =>
 *         typeof body === "object" && body !== null && "status" in body && body.status === "degraded"
 *           ? Effect.fail(new Degraded())
 *           : Effect.succeed(response))
 *     )),
 *     HttpClient.withCircuitBreaker({
 *       breaker,
 *       classify: (exit) =>
 *         Option.exists(Exit.findErrorOption(exit), (error) => error._tag === "Degraded")
 *           ? CircuitBreaker.failure()
 *           : HttpClient.circuitBreakerClassifier(exit)
 *     })
 *   )
 *
 *   yield* Effect.flip(client.get("http://status.test/"))
 *   const state = yield* breaker.state("http://status.test")
 *   return state._tag
 * }).pipe(Effect.scoped, Effect.provide(CircuitBreaker.layerStoreMemory()))
 *
 * await Effect.runPromise(program) // => "Open"
 * ```
 *
 * @stability experimental
 * @category circuit breaking
 * @since 4.0.7
 */
export const withCircuitBreaker: {
  /**
   * Guards requests with a `CircuitBreaker`.
   *
   * **Details**
   *
   * Requests are keyed by origin unless `key` is set, and classified with
   * `circuitBreakerClassifier` unless `classify` is set. A rejected request
   * fails with `CircuitBreakerError` without reaching the wrapped client.
   *
   * Apply it after `withRateLimiter` and `retryTransient`, so the breaker sees
   * one outcome per call and an open circuit skips the retry loop.
   * `retryTransient` never retries a `CircuitBreakerError`. A custom `classify`
   * can delegate the cases it doesn't handle to `circuitBreakerClassifier`.
   *
   * **Gotchas**
   *
   * - The breaker only sees the response headers. To count an error in the
   *   body, lift it into the error channel below the breaker with
   *   `transformResponse` and count it in `classify`.
   * - `withRateLimiter` retries `429` without limit by default, which can hold
   *   the probe slot for minutes. Set its `times`.
   * - A rejected request has no client span. The rejection fails the caller's
   *   span instead.
   *
   * **Example** (Guarding an API in the recommended order)
   *
   * ```ts import.meta.vitest
   * import { Effect, Layer, Ref, Schedule } from "effect"
   * import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http"
   * import { CircuitBreaker, RateLimiter } from "effect/persistence"
   *
   * const program = Effect.gen(function*() {
   *   const requests = yield* Ref.make(0)
   *   // A dependency that always answers 503.
   *   const unavailable = HttpClient.make((request) =>
   *     Effect.as(Ref.update(requests, (n) => n + 1), HttpClientResponse.fromWeb(request, new Response(null, { status: 503 })))
   *   )
   *
   *   const breaker = yield* CircuitBreaker.make({
   *     tripPolicy: CircuitBreaker.consecutive(1),
   *     openDuration: "30 seconds"
   *   })
   *   const client = unavailable.pipe(
   *     HttpClient.withRateLimiter({
   *       limiter: yield* RateLimiter.RateLimiter,
   *       key: "inventory",
   *       limit: 100,
   *       window: "1 second",
   *       times: 3
   *     }),
   *     HttpClient.retryTransient({ times: 2, schedule: Schedule.exponential("1 millis") }),
   *     HttpClient.withCircuitBreaker({ breaker })
   *   )
   *
   *   // Three attempts, then the breaker records one failure and opens.
   *   yield* client.execute(HttpClientRequest.get("http://inventory.test/items"))
   *   // Rejected before the retry loop starts, so no further request is sent.
   *   const rejected = yield* Effect.flip(client.execute(HttpClientRequest.get("http://inventory.test/items")))
   *
   *   return [yield* Ref.get(requests), rejected._tag]
   * }).pipe(
   *   Effect.scoped,
   *   Effect.provide(Layer.merge(
   *     CircuitBreaker.layerStoreMemory(),
   *     RateLimiter.layer.pipe(Layer.provide(RateLimiter.layerStoreMemory))
   *   ))
   * )
   *
   * await Effect.runPromise(program) // => [3, "CircuitBreakerError"]
   * ```
   *
   * **Example** (Counting an error in the body as a failure)
   *
   * This API answers `200` with `{ "status": "degraded" }` when it is failing.
   *
   * ```ts import.meta.vitest
   * import { Data, Effect, Exit, Option } from "effect"
   * import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http"
   * import { CircuitBreaker } from "effect/persistence"
   *
   * class Degraded extends Data.TaggedError("Degraded") {}
   *
   * const degraded = HttpClient.make((request) =>
   *   Effect.succeed(HttpClientResponse.fromWeb(request, Response.json({ status: "degraded" })))
   * )
   *
   * const program = Effect.gen(function*() {
   *   const breaker = yield* CircuitBreaker.make({
   *     tripPolicy: CircuitBreaker.consecutive(1),
   *     openDuration: "30 seconds"
   *   })
   *   const client = degraded.pipe(
   *     HttpClient.transformResponse(Effect.flatMap((response) =>
   *       Effect.flatMap(response.json, (body) =>
   *         typeof body === "object" && body !== null && "status" in body && body.status === "degraded"
   *           ? Effect.fail(new Degraded())
   *           : Effect.succeed(response))
   *     )),
   *     HttpClient.withCircuitBreaker({
   *       breaker,
   *       classify: (exit) =>
   *         Option.exists(Exit.findErrorOption(exit), (error) => error._tag === "Degraded")
   *           ? CircuitBreaker.failure()
   *           : HttpClient.circuitBreakerClassifier(exit)
   *     })
   *   )
   *
   *   yield* Effect.flip(client.get("http://status.test/"))
   *   const state = yield* breaker.state("http://status.test")
   *   return state._tag
   * }).pipe(Effect.scoped, Effect.provide(CircuitBreaker.layerStoreMemory()))
   *
   * await Effect.runPromise(program) // => "Open"
   * ```
   *
   * @stability experimental
   * @category circuit breaking
   * @since 4.0.7
   */
  <E, R2 = never>(options: WithCircuitBreaker.Options<E, R2>): <R>(
    self: HttpClient.With<E, R>
  ) => HttpClient.With<E | CircuitBreaker.CircuitBreakerError, R | R2>
  /**
   * Guards requests with a `CircuitBreaker`.
   *
   * **Details**
   *
   * Requests are keyed by origin unless `key` is set, and classified with
   * `circuitBreakerClassifier` unless `classify` is set. A rejected request
   * fails with `CircuitBreakerError` without reaching the wrapped client.
   *
   * Apply it after `withRateLimiter` and `retryTransient`, so the breaker sees
   * one outcome per call and an open circuit skips the retry loop.
   * `retryTransient` never retries a `CircuitBreakerError`. A custom `classify`
   * can delegate the cases it doesn't handle to `circuitBreakerClassifier`.
   *
   * **Gotchas**
   *
   * - The breaker only sees the response headers. To count an error in the
   *   body, lift it into the error channel below the breaker with
   *   `transformResponse` and count it in `classify`.
   * - `withRateLimiter` retries `429` without limit by default, which can hold
   *   the probe slot for minutes. Set its `times`.
   * - A rejected request has no client span. The rejection fails the caller's
   *   span instead.
   *
   * **Example** (Guarding an API in the recommended order)
   *
   * ```ts import.meta.vitest
   * import { Effect, Layer, Ref, Schedule } from "effect"
   * import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http"
   * import { CircuitBreaker, RateLimiter } from "effect/persistence"
   *
   * const program = Effect.gen(function*() {
   *   const requests = yield* Ref.make(0)
   *   // A dependency that always answers 503.
   *   const unavailable = HttpClient.make((request) =>
   *     Effect.as(Ref.update(requests, (n) => n + 1), HttpClientResponse.fromWeb(request, new Response(null, { status: 503 })))
   *   )
   *
   *   const breaker = yield* CircuitBreaker.make({
   *     tripPolicy: CircuitBreaker.consecutive(1),
   *     openDuration: "30 seconds"
   *   })
   *   const client = unavailable.pipe(
   *     HttpClient.withRateLimiter({
   *       limiter: yield* RateLimiter.RateLimiter,
   *       key: "inventory",
   *       limit: 100,
   *       window: "1 second",
   *       times: 3
   *     }),
   *     HttpClient.retryTransient({ times: 2, schedule: Schedule.exponential("1 millis") }),
   *     HttpClient.withCircuitBreaker({ breaker })
   *   )
   *
   *   // Three attempts, then the breaker records one failure and opens.
   *   yield* client.execute(HttpClientRequest.get("http://inventory.test/items"))
   *   // Rejected before the retry loop starts, so no further request is sent.
   *   const rejected = yield* Effect.flip(client.execute(HttpClientRequest.get("http://inventory.test/items")))
   *
   *   return [yield* Ref.get(requests), rejected._tag]
   * }).pipe(
   *   Effect.scoped,
   *   Effect.provide(Layer.merge(
   *     CircuitBreaker.layerStoreMemory(),
   *     RateLimiter.layer.pipe(Layer.provide(RateLimiter.layerStoreMemory))
   *   ))
   * )
   *
   * await Effect.runPromise(program) // => [3, "CircuitBreakerError"]
   * ```
   *
   * **Example** (Counting an error in the body as a failure)
   *
   * This API answers `200` with `{ "status": "degraded" }` when it is failing.
   *
   * ```ts import.meta.vitest
   * import { Data, Effect, Exit, Option } from "effect"
   * import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http"
   * import { CircuitBreaker } from "effect/persistence"
   *
   * class Degraded extends Data.TaggedError("Degraded") {}
   *
   * const degraded = HttpClient.make((request) =>
   *   Effect.succeed(HttpClientResponse.fromWeb(request, Response.json({ status: "degraded" })))
   * )
   *
   * const program = Effect.gen(function*() {
   *   const breaker = yield* CircuitBreaker.make({
   *     tripPolicy: CircuitBreaker.consecutive(1),
   *     openDuration: "30 seconds"
   *   })
   *   const client = degraded.pipe(
   *     HttpClient.transformResponse(Effect.flatMap((response) =>
   *       Effect.flatMap(response.json, (body) =>
   *         typeof body === "object" && body !== null && "status" in body && body.status === "degraded"
   *           ? Effect.fail(new Degraded())
   *           : Effect.succeed(response))
   *     )),
   *     HttpClient.withCircuitBreaker({
   *       breaker,
   *       classify: (exit) =>
   *         Option.exists(Exit.findErrorOption(exit), (error) => error._tag === "Degraded")
   *           ? CircuitBreaker.failure()
   *           : HttpClient.circuitBreakerClassifier(exit)
   *     })
   *   )
   *
   *   yield* Effect.flip(client.get("http://status.test/"))
   *   const state = yield* breaker.state("http://status.test")
   *   return state._tag
   * }).pipe(Effect.scoped, Effect.provide(CircuitBreaker.layerStoreMemory()))
   *
   * await Effect.runPromise(program) // => "Open"
   * ```
   *
   * @stability experimental
   * @category circuit breaking
   * @since 4.0.7
   */
  <E, R, R2 = never>(self: HttpClient.With<E, R>, options: WithCircuitBreaker.Options<E, R2>): HttpClient.With<E | CircuitBreaker.CircuitBreakerError, R | R2>
} = dual(2, <E, R, R2>(
  self: HttpClient.With<E, R>,
  options: WithCircuitBreaker.Options<E, R2>
): HttpClient.With<E | CircuitBreaker.CircuitBreakerError, R | R2> => {
  const keyOption = options.key
  const resolveKey: (request: HttpClientRequest.HttpClientRequest) => string = typeof keyOption === "function"
    ? keyOption
    : keyOption === undefined
    ? requestOrigin
    : constant(keyOption)
  const classify = options.classify ?? circuitBreakerClassifier
  return transform(self, (effect, request) => options.breaker.execute(effect, { key: resolveKey(request), classify }))
})

const requestOrigin = (request: HttpClientRequest.HttpClientRequest): string =>
  Option.match(HttpClientRequest.toUrl(request), {
    onNone: () => request.url,
    onSome: (url) => url.origin
  })

/**
 * The default `withCircuitBreaker` classifier.
 *
 * **Details**
 *
 * - Failure: status 408, 500, 502, 503 or 504, returned or wrapped in a
 *   `StatusCodeError`, and any `TransportError` or `Cause.TimeoutError`.
 * - Success: any other response, including other 4xx, since the dependency
 *   answered.
 * - Ignored: status 429 (left to `withRateLimiter`), `EncodeError`,
 *   `InvalidUrlError`, `DecodeError`, `EmptyBodyError`, unknown typed errors
 *   and defects. HttpClient errors are typed, so a defect here is a bug in
 *   the caller.
 *
 * When a cause holds several errors, a failure beats a success and a success
 * beats an ignored outcome. A failure carries the longest `Retry-After` it
 * saw. The result is an `Effect` only because parsing an HTTP-date
 * `Retry-After` reads `Clock`.
 *
 * **Gotchas**
 *
 * `TransportError` also covers client-side refusals, which count as failures.
 *
 * @stability experimental
 * @category circuit breaking
 * @since 4.0.7
 */
export const circuitBreakerClassifier = <E>(
  exit: Exit.Exit<HttpClientResponse.HttpClientResponse, E>
): Effect.Effect<CircuitBreaker.Outcome> =>
  Effect.clockWith((clock) => Effect.succeed(classifyCircuitBreakerExit(exit, clock.currentTimeMillisUnsafe())))

const classifyCircuitBreakerExit = <E>(
  exit: Exit.Exit<HttpClientResponse.HttpClientResponse, E>,
  nowMillis: number
): CircuitBreaker.Outcome => {
  if (Exit.isSuccess(exit)) {
    const outcome = circuitBreakerStatusOutcome(exit.value.status)
    return outcome === "Failure" ? circuitBreakerFailure(retryAfterOf(exit.value, nowMillis)) : { _tag: outcome }
  }
  let failed = false
  let succeeded = false
  let retryAfter: Duration.Duration | undefined
  for (const reason of exit.cause.reasons) {
    if (!Cause.isFailReason(reason)) {
      continue
    }
    const outcome = circuitBreakerErrorOutcome(reason.error)
    if (outcome === "Failure") {
      failed = true
      const hint = retryAfterOf(reason.error, nowMillis)
      if (hint !== undefined) {
        retryAfter = retryAfter === undefined ? hint : Duration.max(retryAfter, hint)
      }
    } else if (outcome === "Success") {
      succeeded = true
    }
  }
  return failed ? circuitBreakerFailure(retryAfter) : { _tag: succeeded ? "Success" : "Ignored" }
}

const circuitBreakerFailure = (retryAfter: Duration.Duration | undefined): CircuitBreaker.Outcome => ({
  _tag: "Failure",
  retryAfter
})

const circuitBreakerErrorOutcome = (error: unknown): CircuitBreaker.Outcome["_tag"] => {
  if (Cause.isTimeoutError(error)) {
    return "Failure"
  }
  if (!Error.isHttpClientError(error)) {
    return "Ignored"
  }
  switch (error.reason._tag) {
    case "TransportError":
      return "Failure"
    case "StatusCodeError":
      return circuitBreakerStatusOutcome(error.reason.response.status)
    default:
      return "Ignored"
  }
}

const circuitBreakerStatusOutcome = (status: number): CircuitBreaker.Outcome["_tag"] =>
  status === 429
    ? "Ignored"
    : status === 408 || status === 500 || status === 502 || status === 503 || status === 504
    ? "Failure"
    : "Success"

interface RateLimiterHeaderNames {
  readonly limit: ReadonlyArray<string>
  readonly remaining: ReadonlyArray<string>
  readonly reset: ReadonlyArray<string>
  readonly resetAfter: ReadonlyArray<string>
  readonly retryAfter: ReadonlyArray<string>
}

const resolveRateLimiterHeaderNames = (
  responseHeaders: WithRateLimiter.Options["responseHeaders"]
): RateLimiterHeaderNames => ({
  limit: responseHeaders?.limit === undefined
    ? ["ratelimit-limit", "x-ratelimit-limit"]
    : [responseHeaders.limit.toLowerCase()],
  remaining: responseHeaders?.remaining === undefined
    ? ["ratelimit-remaining", "x-ratelimit-remaining"]
    : [responseHeaders.remaining.toLowerCase()],
  reset: responseHeaders?.reset === undefined
    ? ["ratelimit-reset", "x-ratelimit-reset"]
    : [responseHeaders.reset.toLowerCase()],
  resetAfter: responseHeaders?.resetAfter === undefined
    ? ["ratelimit-reset-after", "x-ratelimit-reset-after"]
    : [responseHeaders.resetAfter.toLowerCase()],
  retryAfter: responseHeaders?.retryAfter === undefined
    ? ["retry-after"]
    : [responseHeaders.retryAfter.toLowerCase()]
})

interface RateLimiterState {
  readonly limit: number
  readonly window: Duration.Duration
  readonly initial: boolean
}

interface RateLimitBudget {
  /** Total tokens admitted for the key. */
  sent: number
  /** The `sent` total of the request whose remaining count was last applied. */
  observed: number
  /** The remaining count reported in response to the `observed` request. */
  remaining: number
  /** When the server budget resets, in epoch milliseconds. */
  resetAt: number
}

const parseRateLimiterState = (
  state: RateLimiterState,
  clock: Clock,
  headers: Headers.Headers,
  tokens: number,
  headerNames: RateLimiterHeaderNames
): RateLimiterState => {
  const limit = parseRateLimitLimit(state, headers, tokens, headerNames) ?? state.limit
  const window = parseRateLimitWindow(clock, headers, headerNames) ?? state.window
  if (limit === state.limit && Duration.equals(window, state.window)) {
    return state
  }
  return { limit, window, initial: false }
}

const parseRateLimitLimit = (
  state: RateLimiterState,
  headers: Headers.Headers,
  tokens: number,
  headerNames: RateLimiterHeaderNames
): number | undefined => {
  const raw = getHeader(headers, ...headerNames.limit)
  const value = parseNumberHeader(raw)
  if (value !== undefined && value > 0) {
    return value
  }
  const remaining = parseRateLimitRemaining(headers, headerNames)
  if (remaining === undefined) {
    return undefined
  }
  return state.initial ? remaining + tokens : Math.max(remaining + tokens, state.limit)
}

const parseRateLimitRemaining = (
  headers: Headers.Headers,
  headerNames: RateLimiterHeaderNames
): number | undefined => {
  const raw = getHeader(headers, ...headerNames.remaining)
  const value = parseNumberHeader(raw)
  return value !== undefined && value >= 0 ? value : undefined
}

const parseRateLimitWindow = (
  clock: Clock,
  headers: Headers.Headers,
  headerNames: RateLimiterHeaderNames
): Duration.Duration | undefined => {
  const resetAfter = parseResetAfter(getHeader(headers, ...headerNames.resetAfter))
  if (resetAfter !== undefined) {
    return resetAfter
  }
  return parseResetHeader(clock, getHeader(headers, ...headerNames.reset))
}

// An invalid Retry-After is treated as absent (RFC 9110 §10.2.3); the
// one millisecond floor keeps a past date or `0` from retrying immediately.
const parseRetryAfter = (
  nowMillis: number,
  value: string | undefined
): Duration.Duration | undefined => {
  if (value === undefined) {
    return undefined
  }
  const retryAfter = Headers.parseRetryAfter(value)
  return Result.isSuccess(retryAfter)
    ? Duration.max(Headers.retryAfterDelay(retryAfter.success, nowMillis), Duration.millis(1))
    : undefined
}

const parseResetAfter = (value: string | undefined): Duration.Duration | undefined => {
  const numeric = parseNumberHeader(value)
  if (numeric === undefined || numeric <= 0) {
    return undefined
  }
  return Duration.max(Duration.seconds(numeric), Duration.millis(1))
}

const parseResetHeader = (
  clock: Clock,
  value: string | undefined
): Duration.Duration | undefined => {
  const numeric = parseNumberHeader(value)
  if (numeric === undefined || numeric <= 0) {
    return undefined
  }
  const nowMillis = clock.currentTimeMillisUnsafe()
  if (numeric > 1_000_000_000_000) {
    return Duration.millis(Math.max(numeric - nowMillis, 1))
  }
  if (numeric > 1_000_000_000) {
    return Duration.millis(Math.max((numeric * 1_000) - nowMillis, 1))
  }
  return Duration.max(Duration.seconds(numeric), Duration.millis(1))
}

const parseNumberHeader = (value: string | undefined): number | undefined => {
  if (value === undefined) {
    return undefined
  }
  const match = /-?\d+(?:\.\d+)?/.exec(value)
  if (match === null) {
    return undefined
  }
  const parsed = Number(match[0])
  return Number.isFinite(parsed) ? parsed : undefined
}

const getHeader = (headers: Headers.Headers, ...keys: Array<string>): string | undefined => {
  for (let i = 0; i < keys.length; i++) {
    const value = headers[keys[i]]
    if (value !== undefined) {
      return value
    }
  }
  return undefined
}

/**
 * Performs an additional effect after a successful request.
 *
 * @stability unstable
 * @category sequencing
 * @since 4.0.0
 */
export const tap: {
  /**
   * Performs an additional effect after a successful request.
   *
   * @stability unstable
   * @category sequencing
   * @since 4.0.0
   */
  <_, E2, R2>(
    f: (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<_, E2, R2>
  ): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | E2, R | R2>
  /**
   * Performs an additional effect after a successful request.
   *
   * @stability unstable
   * @category sequencing
   * @since 4.0.0
   */
  <E, R, _, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<_, E2, R2>
  ): HttpClient.With<E | E2, R | R2>
} = dual(
  2,
  <E, R, _, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<_, E2, R2>
  ): HttpClient.With<E | E2, R | R2> => transformResponse(self, Effect.tap(f))
)

/**
 * Performs an additional effect after an unsuccessful request.
 *
 * @stability unstable
 * @category sequencing
 * @since 4.0.0
 */
export const tapError: {
  /**
   * Performs an additional effect after an unsuccessful request.
   *
   * @stability unstable
   * @category sequencing
   * @since 4.0.0
   */
  <_, E, E2, R2>(f: (e: NoInfer<E>) => Effect.Effect<_, E2, R2>): <R>(self: HttpClient.With<E, R>) => HttpClient.With<E | E2, R | R2>
  /**
   * Performs an additional effect after an unsuccessful request.
   *
   * @stability unstable
   * @category sequencing
   * @since 4.0.0
   */
  <E, R, _, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (e: NoInfer<E>) => Effect.Effect<_, E2, R2>
  ): HttpClient.With<E | E2, R | R2>
} = dual(
  2,
  <E, R, _, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (e: NoInfer<E>) => Effect.Effect<_, E2, R2>
  ): HttpClient.With<E | E2, R | R2> => transformResponse(self, Effect.tapError(f))
)

/**
 * Performs an additional effect on the request before sending it.
 *
 * @stability unstable
 * @category sequencing
 * @since 4.0.0
 */
export const tapRequest: {
  /**
   * Performs an additional effect on the request before sending it.
   *
   * @stability unstable
   * @category sequencing
   * @since 4.0.0
   */
  <_, E2, R2>(f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<_, E2, R2>): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E | E2, R | R2>
  /**
   * Performs an additional effect on the request before sending it.
   *
   * @stability unstable
   * @category sequencing
   * @since 4.0.0
   */
  <E, R, _, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<_, E2, R2>
  ): HttpClient.With<E | E2, R | R2>
} = dual(
  2,
  <E, R, _, E2, R2>(
    self: HttpClient.With<E, R>,
    f: (a: HttpClientRequest.HttpClientRequest) => Effect.Effect<_, E2, R2>
  ): HttpClient.With<E | E2, R | R2> =>
    makeWith(self.postprocess as any, (request) => Effect.tap(self.preprocess(request), f))
)

/**
 * Adds a `Ref` of stored cookies to the client for handling cookies across
 * requests.
 *
 * **When to use**
 *
 * Use to add shared cookie storage to a client so response cookies are retained
 * and sent by later requests to a matching host, path, and scheme.
 *
 * **Details**
 *
 * Response cookies are merged into the ref with `Cookies.mergeIntoArray` for
 * the response URL. When a request is sent, `Cookies.toRequestCookieHeader`
 * selects the cookies for its final URL, after later transformations such as
 * `HttpClientRequest.prependUrl`, and sets them as the `cookie` header. With
 * `followRedirects` applied after `withCookiesRef`, this runs for every hop.
 * Expiry uses the current `Clock`.
 *
 * @stability unstable
 * @category cookies
 * @since 4.0.0
 */
export const withCookiesRef: {
  /**
   * Adds a `Ref` of stored cookies to the client for handling cookies across
   * requests.
   *
   * **When to use**
   *
   * Use to add shared cookie storage to a client so response cookies are retained
   * and sent by later requests to a matching host, path, and scheme.
   *
   * **Details**
   *
   * Response cookies are merged into the ref with `Cookies.mergeIntoArray` for
   * the response URL. When a request is sent, `Cookies.toRequestCookieHeader`
   * selects the cookies for its final URL, after later transformations such as
   * `HttpClientRequest.prependUrl`, and sets them as the `cookie` header. With
   * `followRedirects` applied after `withCookiesRef`, this runs for every hop.
   * Expiry uses the current `Clock`.
   *
   * @stability unstable
   * @category cookies
   * @since 4.0.0
   */
  (ref: Ref.Ref<ReadonlyArray<Cookies.Cookie>>): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E, R>
  /**
   * Adds a `Ref` of stored cookies to the client for handling cookies across
   * requests.
   *
   * **When to use**
   *
   * Use to add shared cookie storage to a client so response cookies are retained
   * and sent by later requests to a matching host, path, and scheme.
   *
   * **Details**
   *
   * Response cookies are merged into the ref with `Cookies.mergeIntoArray` for
   * the response URL. When a request is sent, `Cookies.toRequestCookieHeader`
   * selects the cookies for its final URL, after later transformations such as
   * `HttpClientRequest.prependUrl`, and sets them as the `cookie` header. With
   * `followRedirects` applied after `withCookiesRef`, this runs for every hop.
   * Expiry uses the current `Clock`.
   *
   * @stability unstable
   * @category cookies
   * @since 4.0.0
   */
  <E, R>(self: HttpClient.With<E, R>, ref: Ref.Ref<ReadonlyArray<Cookies.Cookie>>): HttpClient.With<E, R>
} = dual(
  2,
  <E, R>(
    self: HttpClient.With<E, R>,
    ref: Ref.Ref<ReadonlyArray<Cookies.Cookie>>
  ): HttpClient.With<E, R> => {
    const now = () => Fiber.getCurrent()!.getRef(Clock).currentTimeMillisUnsafe()
    const addCookies = (request: HttpClientRequest.HttpClientRequest) =>
      Effect.map(Ref.get(ref), (cookies) => {
        const header = Cookies.toRequestCookieHeader(cookies, request.url, now())
        if (header === undefined) return request
        return HttpClientRequest.setHeader(request, "cookie", header)
      })
    return makeWith(
      (request: Effect.Effect<HttpClientRequest.HttpClientRequest, E, R>) =>
        Effect.tap(
          self.postprocess(Effect.flatMap(request, addCookies)),
          (response) => Ref.update(ref, Cookies.mergeIntoArray(response.url, response.cookies, now()))
        ),
      self.preprocess
    )
  }
)

/**
 * Attaches every request the client sends to the current `Scope`, and aborts
 * them when the scope closes.
 *
 * **When to use**
 *
 * Use when a response body, an upgraded socket or a `toWeb` hand-off must
 * stay open after the response effect completes, and close it by closing the
 * scope.
 *
 * **Details**
 *
 * Ownership follows the execution, not the request value. Each request the
 * transport sends while this client executes belongs to the scope: every
 * redirect hop, retry attempt and request rewritten by middleware, whichever
 * side of `followRedirects`, `withCookiesRef` or `retryTransient` the
 * `withScope` is on. Reusing one request, or one response effect,
 * concurrently under different scopes gives each execution its own owner.
 *
 * Closing the scope aborts pending requests and open response bodies. A
 * request sent after the scope has closed is aborted before the transport
 * starts it. Interrupting a request before its response arrives still aborts
 * it, so a `timeout` that fires before then releases the connection. Once a
 * response is returned, its body is released only when the scope closes.
 *
 * **Gotchas**
 *
 * Requests that middleware sends with another client while this client
 * executes, such as a token fetch in `mapRequestEffect`, are also attached to
 * the scope. When `withScope` is nested, the innermost one owns the requests,
 * so to give a helper request a different lifetime, apply `withScope` to the
 * helper client and run its request in its own scope, for example with
 * `Effect.scoped`.
 *
 * @stability unstable
 * @category resource management
 * @since 4.0.0
 */
export const withScope = <E, R>(
  self: HttpClient.With<E, R>
): HttpClient.With<E, R | Scope.Scope> =>
  transformResponse(self, Effect.provideServiceEffect(RequestScope, Effect.scope))

/**
 * Enables following HTTP redirects up to a specified number of times.
 *
 * **Details**
 *
 * Follows `3xx` responses that include a `Location` header, up to
 * `maxRedirects` (default `10`) times. When the limit is reached or the
 * `Location` header is not a valid URL, the last redirect response is returned.
 *
 * **Gotchas**
 *
 * This only sees redirects that the underlying client returns. `fetch`
 * follows redirects itself by default, so with `FetchHttpClient` provide
 * `FetchHttpClient.RequestInit` with `{ redirect: "manual" }`. Browsers return
 * an opaque response without a `Location` header for manual redirects, so
 * this cannot follow them there.
 *
 * **Example** (Following redirects with FetchHttpClient)
 *
 * ```ts
 * import { Effect } from "effect"
 * import { FetchHttpClient, HttpClient } from "effect/http"
 *
 * const program = Effect.gen(function*() {
 *   const client = (yield* HttpClient.HttpClient).pipe(
 *     HttpClient.followRedirects(5)
 *   )
 *   return yield* client.get("https://example.com/redirect")
 * }).pipe(
 *   Effect.provide(FetchHttpClient.layer),
 *   Effect.provideService(FetchHttpClient.RequestInit, { redirect: "manual" })
 * )
 * ```
 *
 * @stability unstable
 * @category redirects
 * @since 4.0.0
 */
export const followRedirects: {
  /**
   * Enables following HTTP redirects up to a specified number of times.
   *
   * **Details**
   *
   * Follows `3xx` responses that include a `Location` header, up to
   * `maxRedirects` (default `10`) times. When the limit is reached or the
   * `Location` header is not a valid URL, the last redirect response is returned.
   *
   * **Gotchas**
   *
   * This only sees redirects that the underlying client returns. `fetch`
   * follows redirects itself by default, so with `FetchHttpClient` provide
   * `FetchHttpClient.RequestInit` with `{ redirect: "manual" }`. Browsers return
   * an opaque response without a `Location` header for manual redirects, so
   * this cannot follow them there.
   *
   * **Example** (Following redirects with FetchHttpClient)
   *
   * ```ts
   * import { Effect } from "effect"
   * import { FetchHttpClient, HttpClient } from "effect/http"
   *
   * const program = Effect.gen(function*() {
   *   const client = (yield* HttpClient.HttpClient).pipe(
   *     HttpClient.followRedirects(5)
   *   )
   *   return yield* client.get("https://example.com/redirect")
   * }).pipe(
   *   Effect.provide(FetchHttpClient.layer),
   *   Effect.provideService(FetchHttpClient.RequestInit, { redirect: "manual" })
   * )
   * ```
   *
   * @stability unstable
   * @category redirects
   * @since 4.0.0
   */
  (maxRedirects?: number | undefined): <E, R>(self: HttpClient.With<E, R>) => HttpClient.With<E, R>
  /**
   * Enables following HTTP redirects up to a specified number of times.
   *
   * **Details**
   *
   * Follows `3xx` responses that include a `Location` header, up to
   * `maxRedirects` (default `10`) times. When the limit is reached or the
   * `Location` header is not a valid URL, the last redirect response is returned.
   *
   * **Gotchas**
   *
   * This only sees redirects that the underlying client returns. `fetch`
   * follows redirects itself by default, so with `FetchHttpClient` provide
   * `FetchHttpClient.RequestInit` with `{ redirect: "manual" }`. Browsers return
   * an opaque response without a `Location` header for manual redirects, so
   * this cannot follow them there.
   *
   * **Example** (Following redirects with FetchHttpClient)
   *
   * ```ts
   * import { Effect } from "effect"
   * import { FetchHttpClient, HttpClient } from "effect/http"
   *
   * const program = Effect.gen(function*() {
   *   const client = (yield* HttpClient.HttpClient).pipe(
   *     HttpClient.followRedirects(5)
   *   )
   *   return yield* client.get("https://example.com/redirect")
   * }).pipe(
   *   Effect.provide(FetchHttpClient.layer),
   *   Effect.provideService(FetchHttpClient.RequestInit, { redirect: "manual" })
   * )
   * ```
   *
   * @stability unstable
   * @category redirects
   * @since 4.0.0
   */
  <E, R>(self: HttpClient.With<E, R>, maxRedirects?: number | undefined): HttpClient.With<E, R>
} = dual((args) => isHttpClient(args[0]), <E, R>(
  self: HttpClient.With<E, R>,
  maxRedirects?: number | undefined
): HttpClient.With<E, R> =>
  makeWith(
    (request) => {
      const loop = (
        request: Effect.Effect<HttpClientRequest.HttpClientRequest, E, R>,
        redirects: number
      ): Effect.Effect<HttpClientResponse.HttpClientResponse, E, R> =>
        Effect.suspend(() => {
          let currentRequest: HttpClientRequest.HttpClientRequest | undefined
          return Effect.flatMap(
            self.postprocess(Effect.map(request, (request) => {
              currentRequest = request
              return request
            })),
            (response) => {
              if (
                response.status < 300 || response.status >= 400 || !response.headers.location ||
                redirects >= (maxRedirects ?? 10)
              ) {
                return Effect.succeed(response)
              }
              const urlResult = Url.fromString(response.headers.location, response.request.url)
              if (Result.isFailure(urlResult)) {
                return Effect.succeed(response)
              }
              const url = urlResult.success
              const request = currentRequest ?? response.request
              let nextRequest = request
              if (
                ((response.status === 301 || response.status === 302) && request.method === "POST") ||
                (response.status === 303 && request.method !== "GET" && request.method !== "HEAD")
              ) {
                nextRequest = HttpClientRequest.setMethod(nextRequest, "GET")
                nextRequest = HttpClientRequest.setBody(nextRequest, HttpBody.empty)
                nextRequest = HttpClientRequest.removeHeader(nextRequest, "content-encoding")
                nextRequest = HttpClientRequest.removeHeader(nextRequest, "content-language")
                nextRequest = HttpClientRequest.removeHeader(nextRequest, "content-location")
              }
              if (url.origin !== new URL(response.request.url).origin) {
                nextRequest = HttpClientRequest.removeHeader(nextRequest, "authorization")
                nextRequest = HttpClientRequest.removeHeader(nextRequest, "proxy-authorization")
                nextRequest = HttpClientRequest.removeHeader(nextRequest, "cookie")
              }
              // Request the Location as sent: setUrl with a URL object would re-encode its query
              const hash = url.hash === "" ? Option.none() : Option.some(url.hash.slice(1))
              url.hash = ""
              nextRequest = HttpClientRequest.makeWith(
                nextRequest.method,
                url.href,
                UrlParams.empty,
                hash,
                nextRequest.headers,
                nextRequest.body
              )
              // Abort the discarded response to release its connection without reading the body
              return Effect.andThen(
                Effect.sync(() => responseControllers.get(response)?.abort()),
                loop(Effect.succeed(nextRequest), redirects + 1)
              )
            }
          )
        })
      return loop(request, 0)
    },
    self.preprocess
  ))

/**
 * Context reference for a predicate that disables client-side tracing for matching outgoing requests.
 *
 * @stability unstable
 * @category services
 * @since 4.0.0
 */
export const TracerDisabledWhen = Context.Reference<
  Predicate.Predicate<HttpClientRequest.HttpClientRequest>
>("effect/http/HttpClient/TracerDisabledWhen", {
  defaultValue: () => constFalse
})

/**
 * Context reference for filtering request and response headers added to client spans.
 *
 * **Details**
 *
 * Header capture is opt-in: the default filter records no headers. Captured
 * headers listed in `Headers.CurrentRedactedNames` are recorded as `<redacted>`.
 *
 * @stability unstable
 * @category services
 * @since 4.0.0
 */
export const TracerHeaderFilter = Context.Reference<
  (headerName: string, phase: "request" | "response") => boolean
>("effect/http/HttpClient/TracerHeaderFilter", {
  defaultValue: () => constFalse
})

/**
 * Context reference that controls whether outgoing client spans are propagated to request headers.
 *
 * **Details**
 *
 * When this is `true`, the client writes the compact B3 `b3` header and the
 * W3C `traceparent` header. The default is on. The client span is still
 * created when this is `false`.
 *
 * **Gotchas**
 *
 * A browser preflight fails when the target does not list `b3` and
 * `traceparent` in `Access-Control-Allow-Headers`. Set this to `false` for
 * those requests.
 *
 * @stability unstable
 * @category services
 * @since 4.0.0
 */
export const TracerPropagationEnabled = Context.Reference<boolean>("effect/http/HttpClient/TracerPropagationEnabled", {
  defaultValue: constTrue
})

/**
 * Context reference for generating the span name used for outgoing client request spans.
 *
 * **Details**
 *
 * Defaults to the request method unchanged.
 *
 * @stability unstable
 * @category services
 * @since 4.0.0
 */
export const SpanNameGenerator = Context.Reference<
  (request: HttpClientRequest.HttpClientRequest) => string
>("effect/http/HttpClient/SpanNameGenerator", {
  defaultValue: () => (request) => request.method
})

/**
 * Creates an `HttpClient` layer and merges the layer construction context into client response effects.
 *
 * @stability unstable
 * @category layers
 * @since 4.0.0
 */
export const layerMergedContext = <E, R>(
  effect: Effect.Effect<HttpClient, E, R>
): Layer.Layer<HttpClient, E, R> =>
  Layer.effect(HttpClient)(
    Effect.contextWith((context: Context.Context<never>) =>
      Effect.map(effect, (client) =>
        transformResponse(
          client,
          Effect.updateContext((input: Context.Context<never>) => Context.merge(context, input))
        ))
    )
  )

// -----------------------------------------------------------------------------
// internal
// -----------------------------------------------------------------------------

const responseRegistry = (() => {
  if ("FinalizationRegistry" in globalThis && globalThis.FinalizationRegistry) {
    const registry = new FinalizationRegistry((controller: AbortController) => {
      try {
        controller.abort()
      } catch {
        // Runtimes such as workerd disallow aborting I/O outside its request context.
      }
    })
    return {
      register(response: HttpClientResponse.HttpClientResponse, controller: AbortController) {
        registry.register(response, controller, response)
      },
      unregister(response: HttpClientResponse.HttpClientResponse) {
        registry.unregister(response)
      }
    }
  }

  const timers = new WeakMap<HttpClientResponse.HttpClientResponse, any>()
  return {
    register(response: HttpClientResponse.HttpClientResponse, controller: AbortController) {
      timers.set(response, setTimeout(() => controller.abort(), 5000))
    },
    unregister(response: HttpClientResponse.HttpClientResponse) {
      const timer = timers.get(response)
      if (timer === undefined) return
      clearTimeout(timer)
      timers.delete(response)
    }
  }
})()

const RequestScope = Context.Reference<Scope.Scope | undefined>("effect/http/HttpClient/RequestScope", {
  defaultValue: () => undefined
})

const responseControllers = new WeakMap<HttpClientResponse.HttpClientResponse, AbortController>()

const trackResponse = (
  response: HttpClientResponse.HttpClientResponse,
  controller: AbortController,
  scoped: boolean,
  urlParamsRedactedNames: ReadonlyArray<string | RegExp>
): HttpClientResponse.HttpClientResponse => {
  // Body readers create errors with the runner's response, while callers hold
  // the wrapper, so both carry the names of the executing fiber.
  Error.addResponseRedactedNames(response, urlParamsRedactedNames)
  if (!scoped) {
    responseRegistry.register(response, controller)
    response = new InterruptibleResponse(response, controller)
    Error.addResponseRedactedNames(response, urlParamsRedactedNames)
  }
  responseControllers.set(response, controller)
  return response
}

class InterruptibleResponse implements HttpClientResponse.HttpClientResponse, Pipeable {
  readonly original: HttpClientResponse.HttpClientResponse
  readonly controller: AbortController

  constructor(
    original: HttpClientResponse.HttpClientResponse,
    controller: AbortController
  ) {
    this.original = original
    this.controller = controller
  }

  readonly [HttpClientResponse.TypeId] = HttpClientResponse.TypeId
  readonly [HttpIncomingMessage.TypeId] = HttpIncomingMessage.TypeId

  private applyInterrupt<A, E, R>(effect: Effect.Effect<A, E, R>) {
    return Effect.suspend(() => {
      responseRegistry.unregister(this.original)
      return Effect.onInterrupt(
        effect,
        () =>
          Effect.sync(() => {
            this.controller.abort()
          })
      )
    })
  }

  get request() {
    return this.original.request
  }

  get url() {
    return this.original.url
  }

  get status() {
    return this.original.status
  }

  get headers() {
    return this.original.headers
  }

  get cookies() {
    return this.original.cookies
  }

  get remoteAddress() {
    return this.original.remoteAddress
  }

  get formData() {
    return this.applyInterrupt(this.original.formData)
  }

  get text() {
    return this.applyInterrupt(this.original.text)
  }

  get json() {
    return this.applyInterrupt(this.original.json)
  }

  get urlParamsBody() {
    return this.applyInterrupt(this.original.urlParamsBody)
  }

  get arrayBuffer() {
    return this.applyInterrupt(this.original.arrayBuffer)
  }

  get upgrade() {
    return this.applyInterrupt(this.original.upgrade)
  }

  [WebSourceSymbol]() {
    const source = getWebSource(this.original)
    // A handed-over Web body outlives this wrapper, so collecting it must not abort the request.
    if (source !== undefined) responseRegistry.unregister(this.original)
    return source
  }

  get stream() {
    return Stream.suspend(() => {
      responseRegistry.unregister(this.original)
      return Stream.ensuring(
        this.original.stream,
        Effect.sync(() => {
          this.controller.abort()
        })
      )
    })
  }

  toJSON() {
    return this.original.toJSON()
  }

  [Inspectable.NodeInspectSymbol]() {
    return this.original[Inspectable.NodeInspectSymbol]()
  }

  pipe() {
    return pipeArguments(this, arguments)
  }
}

/**
 * Returns `true` for an error that `retryTransient` retries by default: a
 * timeout, a transport error, or a status code error with a transient response.
 *
 * **When to use**
 *
 * Use to classify failures the same way `retryTransient` does, for example in a
 * custom retry policy or a circuit breaker.
 *
 * **Example** (Classifying client errors)
 *
 * ```ts import.meta.vitest
 * import { Cause } from "effect"
 * import { HttpClient, HttpClientError, HttpClientRequest } from "effect/http"
 *
 * const request = HttpClientRequest.get("https://example.com")
 * const transportError = new HttpClientError.HttpClientError({
 *   reason: new HttpClientError.TransportError({ request })
 * })
 *
 * HttpClient.isTransientError(transportError) // => true
 * HttpClient.isTransientError(new Cause.TimeoutError()) // => true
 * HttpClient.isTransientError(new Error("boom")) // => false
 * ```
 *
 * @see {@link isTransientResponse} for the response statuses it accepts
 * @see {@link retryTransient} for the retry policy that uses it
 * @stability unstable
 * @category predicates
 * @since 4.1.0
 */
export const isTransientError = (error: unknown): boolean => Cause.isTimeoutError(error) || isTransientHttpError(error)

const isTransientHttpError = (error: unknown) =>
  Error.isHttpClientError(error) &&
  (error.reason._tag === "TransportError" ||
    (error.reason._tag === "StatusCodeError" && isTransientResponse(error.reason.response)))

const retryAfterOf = (input: unknown, nowMillis: number): Duration.Duration | undefined => {
  const response = Error.isHttpClientError(input)
    ? input.response
    : Predicate.hasProperty(input, HttpClientResponse.TypeId)
    ? input as HttpClientResponse.HttpClientResponse
    : undefined
  return parseRetryAfter(nowMillis, response?.headers["retry-after"])
}

const withRetryAfter = <ES, R1>(
  schedule: Schedule.Schedule<unknown, any, ES, R1>
): Schedule.Schedule<unknown, any, ES, R1> =>
  Schedule.fromStep(
    Effect.map(Schedule.toStep(schedule), (step) => (now: number, input: unknown) => {
      const retryAfter = retryAfterOf(input, now)
      if (retryAfter === undefined) {
        return step(now, input)
      }
      return Effect.map(step(now, input), ([output, delay]) => [output, Duration.max(delay, retryAfter)])
    })
  )

const isTooManyRequestsHttpClientError = (
  error: unknown
): error is Error.HttpClientError & { readonly reason: Error.StatusCodeError } =>
  Error.isHttpClientError(error) && error.reason._tag === "StatusCodeError" && error.reason.response.status === 429

/**
 * Returns `true` for a response whose status `retryTransient` retries by
 * default: 408, 429, 500, 502, 503 or 504.
 *
 * **When to use**
 *
 * Use to retry the same responses as `retryTransient` in a custom retry policy.
 *
 * @see {@link isTransientError} for the matching error predicate
 * @see {@link retryTransient} for the retry policy that uses it
 * @stability unstable
 * @category predicates
 * @since 4.1.0
 */
export const isTransientResponse = (response: HttpClientResponse.HttpClientResponse): boolean =>
  response.status === 408 ||
  response.status === 429 ||
  response.status === 500 ||
  response.status === 502 ||
  response.status === 503 ||
  response.status === 504
